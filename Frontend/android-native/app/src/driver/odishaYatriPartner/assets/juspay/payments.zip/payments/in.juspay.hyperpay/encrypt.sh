#! /bin/bash
currDir=$(pwd)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
oSys=$1

for i in *.js; do
    [ -f "$i" ] || break

    inputDir="${currDir}/${i}"
    fName=$(basename "$i" .js)

    if [ "$oSys" == "ios" ]
    then
        if [[ $fName == *"payments-in.juspay.hyperpay-v1-"* ]]
        then
            outputDir="${currDir}/${fName}.jsa"
        else
            outputDir="${currDir}/payments-in.juspay.hyperpay-v1-${fName}.jsa"
        fi
    else
        if [[ $fName == *"payments-in.juspay.hyperpay-v1-"* ]]
        then
            continue
        else
            outputDir="${currDir}/v1-${fName}.jsa"
        fi
    fi
    encScriptDir="${SCRIPT_DIR}/encrypt.js"
    node "$encScriptDir" "$inputDir" "$outputDir"
done