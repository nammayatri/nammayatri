window.hyperpay_icons_version = '1.8w';
if (window.JOS && typeof window.JOS.registerVersion == 'function') {
	 window.JOS.registerVersion(window.JOS.self)('icons')(window.hyperpay_icons_version)();
}
if (window.JOS && typeof window.JOS.registerVersion == "function"){
  window.JOS.registerVersion(window.JOS.self)("icons")(window.hyperpay_icons_version)();
}
window.getIcons = function () {
  var os = window.__OS;
  var isApp = os ? (os.toLowerCase() == "ios" || os.toLowerCase() == "android") : false ;

  var merchantImageHost = isApp ? "" : "https://assets.juspay.in/hyper/bundles/in.juspay.merchants/picasso/images/";
  var themeImageHost = isApp ? "" : "https://assets.juspay.in/hyper/images/themes/fullwidthlayout/"
  var extension = isApp ? "" : ".png";

  return JSON.stringify({
card: merchantImageHost + "jp_card_12_36c_2022_11_21_11_58_33" + extension,
upi: merchantImageHost + "jp_upi_14_3366cc_2022_11_21_11_58_48" + extension,
netBanking: merchantImageHost + "jp_nb_12_3366cc_2022_11_21_12_08_27" + extension,
emi: merchantImageHost + "jp_emi_01_3366cc_2022_11_21_11_59_00" + extension,
foodCard: merchantImageHost + "jp_foodcard_02_3366cc_2022_11_21_12_12_57" + extension,
toolbarBackArrow: merchantImageHost + "jp_toolbarbackarrow_2_333333_2022_11_21_12_07_46" + extension,
next: themeImageHost + "jp_fullwidthlayout_next" + extension,
radio: themeImageHost + "jp_fullwidthlayout_radio" + extension,
tick: merchantImageHost + "jp_tick_02_3366cc_2022_11_21_12_09_00" + extension,
rightArrow: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
rightArrowUPI: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
checkbox: merchantImageHost + "jp_checkbox_01_979797_2022_11_21_12_14_05" + extension,
checkboxSelected: merchantImageHost + "jp_checkboxselected_02_3366cc_2022_11_21_12_08_56" + extension,
cashOD: themeImageHost + "jp_fullwidthlayout_cod" + extension,
rightArrowCard: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
rightArrowNB: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
rightArrowEMI: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
rightArrowFoodCard: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,
circularRadioButton: themeImageHost + "jp_fullwidthlayout_radio" + extension,
expandUPI: merchantImageHost + "jp_upi_14_3366cc_2022_11_21_11_58_48" + extension,
expandAddCard: merchantImageHost + "jp_card_12_36c_2022_11_21_11_58_33" + extension,
wallet: merchantImageHost + "jp_wallet_14_3366cc_2022_11_21_11_58_55" + extension,
expandNB: merchantImageHost + "jp_nb_12_3366cc_2022_11_21_12_08_27" + extension,
rightArrowWallet: merchantImageHost + "jp_rightarrow_2_3366cc_2022_11_21_12_09_27" + extension,})
};
