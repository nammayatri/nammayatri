window.hyperpay_configuration_version='1.0.3';
if (window.JOS && typeof window.JOS.registerVersion == 'function') {
	 window.JOS.registerVersion(window.JOS.self)('config')(window.hyperpay_configuration_version)();
}
    let fontName = "PlusJakartaSans";
    let fonts = [
  {
    "name": "PlusJakartaSans",
    "url": "https://assets.juspay.in/hyper/assets/in.juspay.merchants/fonts/nammayatri/PlusJakartaSans/PlusJakartaSans-Regular.ttf",
    "weight": 400
  },
  {
    "name": "PlusJakartaSans",
    "url": "https://assets.juspay.in/hyper/assets/in.juspay.merchants/fonts/nammayatri/PlusJakartaSans/PlusJakartaSans-SemiBold.ttf",
    "weight": 500
  },
  {
    "name": "PlusJakartaSans",
    "url": "https://assets.juspay.in/hyper/assets/in.juspay.merchants/fonts/nammayatri/PlusJakartaSans/PlusJakartaSans-Bold.ttf",
    "weight": 700
  }
];

    if(window.JBridge && typeof window.JBridge.loadFonts === 'function') {
    window.JBridge.loadFonts(fonts);
    }

    window.getMerchantConfig = function () {
      var configuration = {
  "context": [
    ""
  ],
  "componentMapping": {
    "*.Global": "globalConfig",
    "*.FlowConfig": "flowConfig",
    "*.ScreenConfig": "screenConfig",
    "*.EMIInstrumentsScreen.ListItem": "emiInstrumentListItem",
    "*.EMIStoredCard.ListItem": "emiStoredCardListItem",
    "*.EMIPlansScreen.ScreenConfig": "emiPlansScreenConfig",
    "*.EMICheckoutScreen.ScreenConfig": "emiCheckoutScreenConfig",
    "*.EMIOptionsScreen.ScreenConfig": "emiOptionsScreenConfig",
    "*.Toolbar": "defaultToolbar",
    "*.AmountBar": "defaultAmountBar",
    "*.WebWrapper.AmountBar": "defaultWebAmountBar",
    "*.WebWrapper.PaymentHeader.Toolbar": "defaultWebPaymentHeaderToolbar",
    "*.PrimaryButton": "defaultPrimaryButton",
    "*.Message": "defaultMessage",
    "*.EditText": "defaultEditText",
    "*.ListItem": "defaultListItem",
    "*.GridItem": "defaultGridItem",
    "*.SearchBox": "defaultSearchBox",
    "*.NavBar": "defaultNavBar",
    "*.AddCard": "defaultAddCard",
    "*.EMICheckoutScreen.AddCard": "emiCheckoutAddCard",
    "*.Popup": "defaultPopup",
    "*.SecondaryButton": "defaultSecondaryButton",
    "*.PrestoList": "defaultPrestoList",
    "*.Loader": "defaultLoaderConfig",
    "*.SavedCard.ListItem": "savedCardListItem",
    "*.EMIPlansScreen.ListItem": "emiPlansListItem",
    "*.EMIOptionsScreen.ListItem": "emiOptionsListItem",
    "*.EMICheckoutScreenInstrument.ListItem": "emiCheckoutListItemInstrument",
    "*.PaymentOption.ListItem": "paymentOptionListItem",
    "*.PaymentOption.GenericIntent.ListItem": "paymentOptionGenericIntentListItem",
    "*.AddButton.Toolbar": "webAddButtonToolbar",
    "*.Error.Message": "errorMessage",
    "*.ExpandedViews.ListItem": "expandedViewsListItem",
    "*.OtherBanks.ListItem": "otherBanksListItem",
    "*.SavedVPA.ListItem": "ppSavedVPAListItem",
    "*.InApp.ListItem": "inAppListItem",
    "*.Rewards.ListItem": "rewardsListItem",
    "*.WalletVerifyNumberScreen.EditText": "verifyNumberEditText",
    "*.WalletVerifyOTPScreen.EditText": "verifyOtpEditText",
    "*.PaymentOption.FoodCards.ListItem": "paymentOptionFoodCardsListItem",
    "*.PaymentInfo.Message": "paymentInfoMessage",
    "*.PaymentBottomInfo.Message": "paymentBottomInfo",
    "*.Surcharge.Message": "surchargeMessage",
    "*.Outage.Message": "defaultMessage",
    "RewardsPopup.ScreenConfig": "rewardsScreenConfig",
    "EnableSI.Message": "enableSIBar",
    "RewardsPay.Message": "rewardsPayMessage",
    "SaveDefault.Message": "defaultOptionBar",
    "MandateEducation.PrimaryButton": "mandateEducationPrimaryButton",
    "RewardsEducation.PrimaryButton": "rewardsEducationPrimaryButton",
    "*.OtherUPI.SecondaryButton": "otherUPISecondaryButton",
    "NBScreen.PrimaryButton": "nbPrimaryButton",
    "SingleCard.Message": "singleCardMessage",
    "Screen.Popup": "deletePopupConfig",
    "PaymentStatus.Popup": "paymentStatusPopup",
    "RetrySuggestion.ListItem": "retrySuggestionListItem",
    "ViesEnrollment.Popup": "viesEnrollmentPopupConfig",
    "BackPressDialog.Popup": "backPressDialogPopup",
    "WalletScreen.UnLinked.ListItem": "unlinkedWalletListItem",
    "WalletScreen.Linked.ListItem": "linkedWalletListItem",
    "PaymentManagement.SavedCard.ListItem": "pmSavedCardListItem",
    "PaymentManagement.SavedVPA.ListItem": "pmSavedVPAListItem",
    "QuickPayScreen.Linked.ListItem": "quickPayLinkedWallet",
    "QuickPayScreen.SavedCard.ListItem": "quickPaySavedCard",
    "QuickPayScreen.NetBank.ListItem": "quickPayNB",
    "QuickPayScreen.UpiCollect.ListItem": "quickPayNB",
    "QuickPayScreen.UnlinkedWallets.ListItem": "quickPayUnlinkedWallet",
    "QuickPayScreen.PrimaryButton": "quickPayPrimaryButton",
    "QuickPayScreen.Toolbar": "quickPayToolbar",
    "NBScreen.MandateConsent.Message": "nbMandateConsentMessage",
    "PaymentPage.ExpandedNB.ListItem": "expandedNBBottomListItem",
    "PaymentStatusScreen.ListItem": "paymentStatusListItem",
    "PaymentStatusScreen.SecondaryButton": "paymentStatusSecondaryButton",
    "PaymentStatusScreen.PrimaryButton": "paymentStatusPrimaryButton",
    "NBScreen.SearchBox": "nbScreenSearchBox",
    "*.WalletScreen.ScreenConfig": "walletScreenConfig",
    "PaymentPage.Expanded.LinkedWallet.ListItem": "linkedWalletListItem",
    "PaymentPage.Expanded.UnlinkedWallet.ListItem": "unlinkedWalletListItem",
    "UPIScreen.SavedVPA.ListItem": "savedVPAListItem",
    "PaymentPageScreen.AmountBar": "ppAmountBar",
    "NBScreen.OtherBanks.SecondaryButton": "nbOtherBanksSecondaryButton",
    "UPIScreen.OtherUPI.SecondaryButton": "upiOtherOptionsSecondaryButton",
    "PaymentPage.SavedCard.ListItem": "ppSavedCardListItem",
    "NBScreen.OtherBanks.ListItem": "nbScreenOtherBanksListItem",
    "UPIScreen.UPIApp.ListItem": "upiAppListItem",
    "WebWrapper.PaymentHeader.Toolbar": "webPaymentHeaderToolbar",
    "WebWrapper.Back.Toolbar": "webBackToolBar",
    "COD.ScreenConfig": "codScreen",
    "WalletScreen.Unlinked.ListItem": "unlinkedWalletListItem",
    "UPIAddScreen.ScreenConfig": "upiAddScreen",
    "UPIScreen.*.EditText": "upiScreenEditText",
    "PaymentPage.Outage.Message": "ppOutageMessage",
    "WalletScreen.Outage.Message": "walletOutageMessage",
    "UPIAddScreen.Outage.Message": "upiOutageMessage",
    "EmiScreen.Popup": "EmiPopup",
    "AddCardScreen.ScreenConfig": "addcardScreenConfig",
    "WalletVerifyNumberScreen.ScreenConfig": "walletVerifyNumberScreenConfig",
    "WalletOTPScreen.ScreenConfig": "walletVerifyOTPScreenConfig",
    "PaymentPage.OfferOptions.ListItem": "ppOfferListItem",
    "*.Indeterminate.Loader": "indeterminateLoaderConfig",
    "UPIAddScreen.Toolbar": "upiAddToolbar",
    "QuickPay.Outage.Message": "quickPayOutage",
    "QuickPayScreen.ScreenConfig": "quickPayScreenConfig",
    "Grid.Surcharge.Message": "gridSurchargeMessage",
    "*.Offers.Message": "offerMessage",
    "NBScreen.Surcharge.Message": "nbScreenSurchargeMessage",
    "NBScreenList.Outage.Message": "nbScreenOutageMessage",
    "nbGridOutageMessage.Outage.Message": "gridOutageMessage",
    "UPIScreen.PrimaryButton": "upiScreenPrimaryButton",
    "PaymentPageScreen.CashOD.ListItem": "codListItem",
    "UPIHomeScreen.Outage.Message": "upiHomeScreenOutageMessage",
    "cardOutageMessage.Outage.Message": "cardsOutageMessage",
    "CredScreen.Outage.Message": "credOutageMessage",
    "UPIScreen.PaymentOption.ListItem": "addButtonListItem",
    "WebWrapper.AddButton.ListItem": "addButtonListItem",
    "UPIHomeScreen.ScreenConfig": "UPIHomeScreenConfig",
    "VerifyNumber.PrimaryButton": "walletPrimaryButton",
    "*.OffersNudge.Message": "offersNudgeConfig",
    "OffersPreviewScreen.TermsAndConditions.Message": "offersPreviewTermsAndConditions",
    "OffersPreviewScreen.ListItem": "offersPreviewListItem",
    "UPIAddScreen.Surcharge.Message": "addScreenSurcharge",
    "AddCardScreen.Surcharge.Message": "addScreenSurcharge"
  },
  "mainConfig": {
    "globalConfig": {
      "primaryColor": {
        "#ref": [
          "masterConfig.themes.Colors.primaryColor"
        ]
      },
      "secondaryColor": "#D6D6D6",
      "textPrimaryColor": {
        "#ref": [
          "masterConfig.themes.Colors.defaultTextColor"
        ]
      },
      "textSecondaryColor": "#999999",
      "textTertiaryColor": "#000000",
      "errorColor": {
        "#ref": [
          "masterConfig.themes.Colors.errorColor"
        ]
      },
      "successColor": {
        "#ref": [
          "masterConfig.themes.Colors.successColor"
        ]
      },
      "dividerColor": {
        "#ref": [
          "masterConfig.components.listItems.dividerColor"
        ]
      },
      "hintColor": "#999999",
      "checkboxFontColor": "#6B6B6B",
      "primaryFont": {
        "type": "FontName",
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-Regular\";"
          ]
        }
      },
      "checkboxFont": {
        "type": "FontName",
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-Regular\";"
          ]
        }
      },
      "fontBold": {
        "type": "FontName",
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-Bold\";"
          ]
        }
      },
      "fontSemiBold": {
        "type": "FontName",
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-SemiBold\";"
          ]
        }
      },
      "fontRegular": {
        "type": "FontName",
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-Regular\";"
          ]
        }
      },
      "selectedFont": {
        "value": {
          "#js-expr": [
            "  var fontType = rc('masterConfig.themes.TypoGraphy.fontFamily');\n      fontType + \"-Bold\";"
          ]
        }
      },
      "checkboxSize": 16,
      "fontSize": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          {
            "#ref": [
              "masterConfig.themes.TypoGraphy.desktopFontBaseSize"
            ]
          },
          {
            "#ref": [
              "masterConfig.themes.TypoGraphy.fontBaseSize"
            ]
          }
        ]
      }
    },
    "flowConfig": {
      "useCTATextForInApp": false,
      "cardsConfig": {
        "enableTokenizationConsentPopup": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.cards.tokenizationConsentPopup"
          ]
        }
      },
      "seperateCredEligibility": {
        "#ref": [
          "masterConfig.controls.paymentOptions.dataOfElements.inApps.showCredEvenIfIneligible"
        ]
      },
      "showSavedVPAs": {
        "#ref": [
          "masterConfig.controls.features.showSavedVpas"
        ]
      },
      "cardlessEmiWallets": {
        "#js-expr": [
          "var wallets = [];\nif(rc('masterConfig.controls.paymentOptions.dataOfElements.emi.zestMoney'))\n{\n  wallets.push('ZESTMONEY');\n} \n\nwallets;"
        ]
      },
      "upiQREnable": {
        "#ref": [
          "masterConfig.controls.paymentOptions.dataOfElements.upi.upiScanAndPay"
        ]
      },
      "popularBanks": [
        "NB_SBI",
        "NB_HDFC",
        "NB_ICICI",
        "NB_AXIS"
      ],
      "paymentOptions": {
        "#js-expr": [
          "\nvar paymentOptions = rc('masterConfig.controls.paymentOptions');\nvar po_length = paymentOptions.orderOfElements.length; \nvar arr_obj = []; \nvar nativePo = [];\n\n\n\nfor (var i = 0; i < po_length; i++) {\n    var pos = paymentOptions.orderOfElements[i];\n   \n    if (pos == 'twidPay') {\n      arr_obj.push({ \n        group: 'others', \n        po: 'rewards', \n        onlyDisable: [], \n        visibility: \"VISIBLE\" \n      });\n\n    } \n\n    else if (pos == 'googlePaySdk') {\n      arr_obj.push({ \n        group: 'others', \n        po: 'googlePay', \n        onlyDisable: [], \n        visibility: \"VISIBLE\" \n      });\n\n    } \n\n    else if (pos == 'nb') {\n      arr_obj.push({ \n        group: 'others', \n        po: 'nb', \n        onlyDisable: ['NB_SBM', 'NB_SBT'], \n        visibility: \"VISIBLE\" \n      });\n\n    } \n    \n    else if (pos == 'wallets') {\n      \n      \n      arr_obj.push({ \n        group: 'others', \n        po: 'wallets', \n        onlyDisable: ['CRED'],\n        visibility: \"VISIBLE\" \n      });\n\n    }  \n    \n    else if (pos == 'loanMarketplace') {\n      \n      \n      arr_obj.push({ \n        group: 'others', \n        po: 'loanMarketplace', \n        onlyDisable: [],\n        visibility: \"VISIBLE\" \n      });\n\n    }\n\n    else if (pos == 'upi') {\n\n        var collect = paymentOptions.dataOfElements.upi.collect;\n        var intent = paymentOptions.dataOfElements.upi.intent;\n        \n        \n        if(collect && intent){\n          \n\n          arr_obj.push({\n            group: 'others', \n            po: 'upiAppswithOther', \n            onlyDisable: ['SHAREit', 'WhatsApp'], \n            visibility: \"VISIBLE\"\n          });\n        }\n\n        else if(collect){\n          \n\n          arr_obj.push({ \n            group: 'others', \n            po: 'upi', \n            onlyDisable: [], \n            visibility: \"VISIBLE\" \n          })\n        }\n\n\n        else if(intent){\n          \n          arr_obj.push({ \n            group: 'others', \n            po: 'upiApps', \n            onlyDisable: [], \n            visibility: \"VISIBLE\" \n          });\n        }\n    }\n\n    else if(pos == 'cards'){\n        \n\n        if(!(paymentOptions.dataOfElements.cards.debit)) {\n          arr_obj.push({ \n            group: 'others',\n            po: 'cards', \n            onlyDisable: [\"debit\"] , \n            visibility: \"VISIBLE\"\n          }) \n        }\n\n\n        else if(!(paymentOptions.dataOfElements.cards.credit)) {\n          arr_obj.push({ \n            group: 'others', \n            po: 'cards', \n            onlyDisable: [\"credit\"] , \n            visibility: \"VISIBLE\" \n          }); \n        }\n          \n           \n        else {\n          arr_obj.push({ \n            group: 'others', \n            po: 'cards', \n            onlyDisable: [] , \n            visibility: \"VISIBLE\" \n          }) ;\n        }\n          \n    }\n\n    else {\n      arr_obj.push({ \n          group: 'others', \n          po: pos, \n          onlyDisable: [], \n          visibility: \"VISIBLE\" \n      });\n    }      \n} \n\n\n\nconsole.log('<---mobile', arr_obj);\n\narr_obj;"
        ]
      },
      "managementOptions": [
        {
          "group": "others",
          "po": "cards",
          "visibility": "visible"
        },
        {
          "group": "others",
          "po": "upi",
          "visibility": "visible"
        },
        {
          "group": "others",
          "po": "wallets",
          "visibility": "visible"
        },
        {
          "group": "others",
          "po": "inApps",
          "visibility": "visible"
        }
      ],
      "sideBarTabs": {
        "#if": [
          "window.__payload.action !== 'paymentManagement'",
          {
            "#ref": [
              "flowConfig.sideBarTabsRef"
            ]
          },
          {
            "#js-expr": [
              "rc('flowConfig.sideBarTabsRef').includes('MANAGE') ? ['MANAGE']:[]"
            ]
          }
        ]
      },
      "firstLoadSideBarTab": {
        "#js-expr": [
          "rc('flowConfig.sideBarTabsRef').length==0?'':rc('flowConfig.sideBarTabsRef')[0]"
        ]
      },
      "mandateInstruments": {
        "#js-expr": [
          "var mi = [];   var paymentOptions = rc('masterConfig.controls.paymentOptions');\nif(paymentOptions.dataOfElements.cards.mandates) mi.push(\"cards\"); \nif(paymentOptions.dataOfElements.upi.mandates)  {\n  mi.push(\"intent\");\n  mi.push(\"collect\");\n}\nif(paymentOptions.dataOfElements.wallets.mandates) mi.push(\"wallets\");\nmi;"
        ]
      },
      "outageViewProps": {
        "showOutageView": {
          "#if": [
            {
              "#ref": [
                "masterConfig.controls.features.outage"
              ]
            },
            "true",
            "false"
          ]
        },
        "outageMessage": "Facing fluctuation in payments for"
      },
      "flows": {
        "enableQuickPay": {
          "#ref": [
            "masterConfig.controls.features.quickPay"
          ]
        },
        "directOTP": {
          "#if": [
            {
              "#ref": [
                "masterConfig.controls.features.nativeOTP"
              ]
            },
            "true",
            "false"
          ]
        },
        "tpvEnable": {
          "#if": [
            {
              "#ref": [
                "masterConfig.controls.features.enableTPV"
              ]
            },
            "true",
            "false"
          ]
        },
        "hideIneligiblePayLater": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.paylater.hideIneligiblePayLater"
          ]
        },
        "walletsForSdkFlow": {
          "#js-expr": [
            "var paymentOpt = rc('masterConfig.controls.paymentOptions');\nwalletsdk= []; \n\nif(paymentOpt.dataOfElements.wallets.phonepeQcLite) {\n  walletsdk.push(\"phonepe\");\n}  \nif(paymentOpt.dataOfElements.wallets.paytmInapp) {\n  walletsdk.push(\"paytm\");\n}  \nif(paymentOpt.dataOfElements.googlePaySdk) {\n  walletsdk.push(\"googlepay\");\n} \n \nwalletsdk;"
          ]
        }
      },
      "payeeName": "",
      "drawFromStatusBar": false,
      "vpaSuggestions": {
        "handles": [
          "ybl",
          "paytm",
          "okhdfcbank",
          "okicici",
          "oksbi",
          "okaxis",
          "upi",
          "icici",
          "axl",
          "apl",
          "abfspay",
          "axisb",
          "axisbank",
          "fbl",
          "ibl",
          "idfcbank",
          "ikwik",
          "indus",
          "jupiteraxis",
          "kmbl",
          "myicici",
          "pingpay",
          "tapicici",
          "timecosmos",
          "waaxis",
          "wahdfcbank",
          "waicici",
          "wasbi",
          "yapl",
          "yesbank",
          "pz"
        ],
        "maxShown": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.upi.vpaSuggestionsLimit"
          ]
        }
      },
      "retryPayment": {
        "enableRetry": {
          "#ref": [
            "masterConfig.controls.features.retryPayment.visible"
          ]
        },
        "retryAttempts": {
          "#ref": [
            "masterConfig.controls.features.retryPayment.noOfAttempts"
          ]
        },
        "showLinkedMethodsOnly": false,
        "retrySuggestion": [
          {
            "payment_method_type": "CARD",
            "payment_method": "VISA"
          },
          {
            "payment_method_type": "CARD",
            "payment_method": "MASTERCARD"
          },
          {
            "payment_method_type": "CARD",
            "payment_method": "RUPAY"
          },
          {
            "payment_method_type": "WALLET",
            "payment_method": "SIMPL"
          },
          {
            "payment_method_type": "WALLET",
            "payment_method": "LAZYPAY"
          }
        ]
      },
      "exitPopup": {
        "#ref": [
          "masterConfig.controls.features.showExitPopup"
        ]
      },
      "txnStatus": {
        "enable": {
          "#ref": [
            "masterConfig.controls.features.showPaymentStatusScreen"
          ]
        },
        "pollingCount": -1
      },
      "pageExpiryConfig": {
        "showTimer": {
          "#ref": [
            "masterConfig.controls.features.expiryTimer.showTimer"
          ]
        },
        "enable": {
          "#ref": [
            "masterConfig.controls.features.expiryTimer.visible"
          ]
        },
        "activeTimeInMs": {
          "#ref": [
            "masterConfig.controls.features.expiryTimer.activeTimeInMs"
          ]
        }
      },
      "shell": {
        "timer": {
          "#ref": [
            "masterConfig.controls.features.expiryTimer.visible"
          ]
        }
      },
      "upiConfig": {
        "verifyVPAOnCTAClick": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.upi.upiIdValidation"
          ]
        },
        "skipHomeScreen": {
          "#js-expr": [
            "window.isDesktopView() ? false : true"
          ]
        },
        "enableUPICollect": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.upi.collect"
          ]
        }
      },
      "verifyVpa": {
        "#ref": [
          "masterConfig.controls.paymentOptions.dataOfElements.upi.upiIdValidation"
        ]
      },
      "offers": {
        "isEnabled": {
          "#ref": [
            "masterConfig.components.offers.visible"
          ]
        },
        "isInstantDiscount": true,
        "isPreview": {
          "#ref": [
            "masterConfig.components.offers.banner"
          ]
        },
        "useFlyerMicroapp": false,
        "isSendOfferEvent": false,
        "instruments": [
          "netbanking",
          "cards",
          "intent",
          "collect"
        ],
        "fetchOfferFromFlyer": false,
        "supportedIneligibleOffers": {
          "default": [
            "Amount LessThanMinAmount"
          ]
        },
        "displayGroupOffers": true,
        "enableGroupOfferList": true,
        "enableCouponTextBox": true,
        "enableRetry": true,
        "offerInfoTextSource": "title"
      },
      "flowConfigValues": {
        "blockedMethods": {
          "netBanking": [],
          "cardBrands": [],
          "cardTypes": [],
          "cardBins": [],
          "indianCardsOnly": false,
          "upiCollectBlock": false,
          "errorMsg": "",
          "fadeOutBlockedCards": [],
          "specifiedErrorMessage": {
            "brandError": "",
            "binError": "",
            "countryError": "",
            "typeError": "<> card can't be used"
          }
        },
        "isViesAllowed": "",
        "maxViesAmount": 0
      },
      "sideBarTabsRef": {
        "#js-expr": [
          "var options = {\n  'cards': 'CARD',\n  'wallets':'WALLET',\n  'upi':'UPI',\n  'nb':'NET_BANKING',\n  'inApps':'INAPPS',\n  'paylater':'PAY_LATER',\n  'cashod':'COD',\n  'emi':'EMI',\n  'nocostemi': 'NOCOSTEMI'\n, 'loanMarketplace':'LOANMARKETPLACE'\n}; \n\nvar paymentOptions = rc('masterConfig.controls.paymentOptions');\nvar po_length = paymentOptions.orderOfElements.length; \n\nvar arr = [];  \n\nfor (var i = 0; i < po_length; i++) {\n  var pos = paymentOptions.orderOfElements[i];\n\n  if(pos!='cred' && options[pos])\n    arr.push(options[pos]);\n}\n\nconsole.log('<---desktop', arr);\n\narr;"
        ]
      },
      "savedPaymentOptions": {
        "instruments": {
          "#js-expr": [
            "var arr =  [\"wallets\",\"foodcards\",\"paylater\"];\n\nif((rc('masterConfig.controls.features.showSavedVpas')) == true) {\n  arr.splice(1,0,\"vpas\");\n}  \n\nif((rc('masterConfig.controls.features.showSavedCards')) == true) {\n  arr.splice(1,0,\"cards\");\n} \n\narr;"
          ]
        },
        "webInstruments": {
          "#js-expr": [
            "var arr =  [\"foodcards\"];  \n\nif((rc('masterConfig.controls.features.showSavedCards')) == true) {\n  arr.splice(1,0,\"cards\");\n} \n\narr;"
          ]
        }
      },
      "enableSurcharge": {
        "#ref": [
          "masterConfig.controls.features.surcharge.visible"
        ]
      }
    },
    "UPIHomeScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "utils.sectionMargin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                }
              ]
            ]
          },
          "containerAttribs.horizontalSpacing": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              {
                "#ref": [
                  "masterConfig.components.container.cardMargin"
                ]
              },
              0
            ]
          }
        }
      ]
    },
    "quickPayScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "uiCard.horizontalPadding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 0 : padding"
            ]
          },
          "utils.sectionMargin": [
            0,
            0,
            0,
            10
          ]
        }
      ]
    },
    "walletVerifyOTPScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "sectionHeader.textSize": 12,
          "containerAttribs.margin": [
            0,
            0,
            0,
            0
          ],
          "sectionHeader.padding": [
            0,
            10,
            0,
            0
          ],
          "utils.sectionMargin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                },
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                }
              ]
            ]
          }
        }
      ]
    },
    "walletVerifyNumberScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "containerAttribs.margin": [
            0,
            0,
            0,
            0
          ],
          "utils.sectionMargin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                },
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                }
              ]
            ]
          }
        }
      ]
    },
    "addcardScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "bgPrimaryColor": {
            "#ref": [
              "screenConfig.bgPrimaryColor"
            ]
          }
        }
      ]
    },
    "upiAddScreen": {
      "#override": [
        "screenConfig",
        {
          "sectionHeader.padding": [
            1,
            20,
            24,
            16
          ],
          "uiCard.horizontalPadding": 24,
          "uiCard.verticalPadding": 20,
          "sectionHeader.dividerVisibility": "GONE",
          "sectionHeader.margin": [
            0,
            0,
            0,
            0
          ],
          "containerAttribs.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              {
                "#ref": [
                  "masterConfig.components.container.containerPadding"
                ]
              }
            ]
          },
          "utils.sectionMargin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                26,
                10,
                50,
                10
              ],
              [
                0,
                0,
                0,
                {
                  "#ref": [
                    "masterConfig.components.container.cardMargin"
                  ]
                }
              ]
            ]
          }
        }
      ]
    },
    "codScreen": {
      "#override": [
        "screenConfig",
        {
          "sectionHeader.text": "Pay On Delivery"
        }
      ]
    },
    "walletScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "sectionHeader.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                20,
                0,
                0
              ],
              {
                "#ref": [
                  "masterConfig.components.sectionHeader.sectionHeaderPadding"
                ]
              }
            ]
          },
          "containerAttribs.horizontalSpacing": {
            "#js-expr": [
              " var padding = rc('masterConfig.components.container.containerPadding');\n     padding[0];"
            ]
          }
        }
      ]
    },
    "emiOptionsScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "sectionHeader.visibility": "VISIBLE",
          "utils.contentMargin": {
            "#js-expr": [
              " var vSpace = rc('screenConfig.containerAttribs.verticalSpacing');\n            var hSpace = rc('screenConfig.containerAttribs.horizontalSpacing') + 12;\n            if(rc('screenConfig.containerAttribs.horizontalSpacing') == 0){\n              window.isDesktopView() ? [0,0,0,0] : rc('masterConfig.components.container.containerPadding')\n            }\n            else{\n              window.isDesktopView() ? [2,0,0,0] : [100, vSpace, hSpace, vSpace]\n            }\n          "
            ]
          },
          "uiCard.horizontalPadding": 0
        }
      ]
    },
    "screenConfig": {
      "useIndeterminateSubtleLoader": "subtleloader",
      "bgPrimaryColor": {
        "#ref": [
          "masterConfig.themes.Colors.backgroundColor"
        ]
      },
      "bgSecondaryColor": "#FDFDFD",
      "ctaSurcharge": {
        "#js-expr": [
          "var value = rc('masterConfig.controls.features.surcharge.surchargeOnButton')\nif(rc('masterConfig.controls.features.surcharge.surchargeOnButton') == 'Nothing')\n{\n  value = undefined\n}\nvalue;"
        ]
      },
      "amountBarSurcharge": {
        "#js-expr": [
          "var value = undefined\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalOnly')\n{\n  value = 'BarTotalOnly'\n}\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge'){\n  value = 'BarTotalWithSurcharge'\n}\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split'){\n  value = 'BarSplit'\n}\nvalue;"
        ]
      },
      "surchargeInfoText": {
        "margin": {
          "#js-expr": [
            "var imageSize = rc('defaultPrestoList.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var\n  extras = 10; if (window.isDesktopView()){\n    extras = 10;\n    padding = 26;\n  } \n\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
          ]
        }
      },
      "offerInfoText": {
        "margin": {
          "#js-expr": [
            "var imageSize = rc('defaultPrestoList.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var\n  extras = 10; if (window.isDesktopView()){\n    extras = 10;\n    padding = 26;\n  } \n\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
          ]
        }
      },
      "containerAttribs": {
        "horizontalSpacing": 0,
        "verticalSpacing": 0,
        "sectionSpacing": {
          "#ref": [
            "masterConfig.components.container.cardMargin"
          ]
        },
        "margin": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            [
              24,
              10,
              0,
              24
            ],
            {
              "#ref": [
                "masterConfig.components.container.containerPadding"
              ]
            }
          ]
        }
      },
      "utils": {
        "contentMargin": {
          "#ref": [
            "masterConfig.components.container.containerPadding"
          ]
        },
        "sectionMargin": [
          0,
          0,
          0,
          {
            "#ref": [
              "masterConfig.components.container.cardMargin"
            ]
          }
        ]
      },
      "uiCard": {
        "translation": {
          "#if": [
            {
              "#ref": [
                "masterConfig.themes.Shadow.cardShadow.visible"
              ]
            },
            {
              "#js-expr": [
                "var nativeShadow = rc('masterConfig.themes.Shadow.cardShadow.nativeShadow');\nnativeShadow == 0 ? 0.1 : nativeShadow"
              ]
            },
            0.1
          ]
        },
        "cornerRadius": {
          "#ref": [
            "masterConfig.components.container.cornerRadius"
          ]
        },
        "horizontalPadding": {
          "#js-expr": [
            "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 0 : padding"
          ]
        },
        "verticalPadding": 10,
        "color": {
          "#ref": [
            "masterConfig.themes.Colors.defaultTileColor"
          ]
        },
        "stroke": {
          "#js-expr": [
            "var strokeColor = rc('masterConfig.components.container.strokeColor');\nvar strokeWidth = rc('masterConfig.components.container.strokeWidth');\n                  window.isDesktopView() ? '' : strokeWidth+\",\"+strokeColor"
          ]
        },
        "addStrokeToForm": true,
        "shadow": {
          "spread": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.visible"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.spread"
                ]
              },
              0
            ]
          },
          "blur": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.visible"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.blur"
                ]
              },
              0
            ]
          },
          "opacity": 0,
          "hOffset": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.visible"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.xOffset"
                ]
              },
              0
            ]
          },
          "vOffset": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.visible"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.yOffset"
                ]
              },
              0
            ]
          },
          "color": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.visible"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Shadow.cardShadow.color"
                ]
              },
              {
                "#ref": [
                  "masterConfig.themes.Colors.backgroundColor"
                ]
              }
            ]
          }
        }
      },
      "button": {
        "placeBtnInCard": true,
        "addAmountToText": false,
        "background": {
          "#ref": [
            "screenConfig.bgPrimaryColor"
          ]
        },
        "maxWidth": {
          "#js-expr": [
            "(window.__OS.toLowerCase() === \"web\") && window.isDesktopView() ? 223 : \"match_parent\""
          ]
        }
      },
      "sectionHeader": {
        "text": "",
        "font": {
          "#js-expr": [
            "if (window.isDesktopView()) {\n        rc('globalConfig.fontSemiBold')\n      } else {\n        rc('globalConfig.fontBold')\n      }"
          ]
        },
        "textSize": {
          "#ref": [
            "masterConfig.components.sectionHeader.fontSize"
          ]
        },
        "bottomMargin": 2,
        "margin": {
          "#js-expr": [
            " if (window.isDesktopView()) {\n            [0, 18, 0, 0]\n          } else {\n            var uiPadding = rc('screenConfig.uiCard.horizontalPadding');\n            var hSpace = rc('screenConfig.containerAttribs.horizontalSpacing');\n            var bottomMargin = rc('screenConfig.sectionHeader.bottomMargin');\n            var tM = (rc('screenConfig.uiCard.translation') == 0.0) ? 0 : 4\n            if (hSpace == 0){\n              [0, 0, 0, bottomMargin]\n            }\n            else {\n              [0, 0, 0, bottomMargin]\n            }\n          }\n        "
          ]
        },
        "padding": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            [
              28,
              0,
              24,
              16
            ],
            {
              "#ref": [
                "masterConfig.components.sectionHeader.sectionHeaderPadding"
              ]
            }
          ]
        },
        "dividerHeight": 1,
        "dividerColor": "#ffffff",
        "dividerVisibility": "GONE",
        "color": {
          "#ref": [
            "masterConfig.components.sectionHeader.fontColor"
          ]
        },
        "alpha": 1,
        "background": {
          "#js-expr": [
            "if (window.isDesktopView()) {\n        rc('masterConfig.themes.Colors.defaultTileColor')\n      } else {\n        rc('masterConfig.themes.Colors.backgroundColor')\n      }"
          ]
        },
        "visibility": {
          "#if": [
            {
              "#ref": [
                "masterConfig.components.sectionHeader.visible"
              ]
            },
            "VISIBLE",
            "GONE"
          ]
        }
      },
      "sideBar": {
        "background": "#f8f8f8",
        "icon": {
          "selectedColor": {
            "#ref": [
              "masterConfig.desktopView.icon.selectedColor"
            ]
          },
          "notSelectedColor": {
            "#ref": [
              "masterConfig.desktopView.icon.notSelectedColor"
            ]
          }
        },
        "navbarItem": {
          "useExternalImage": false,
          "selectedBackgroundColor": {
            "#ref": [
              "masterConfig.desktopView.sideBar.selectedBackgroundColor"
            ]
          },
          "fontColor": {
            "#ref": [
              "masterConfig.desktopView.sideBar.unSelectedTextColor"
            ]
          },
          "selectedFontColor": {
            "#ref": [
              "masterConfig.desktopView.sideBar.selectedTextColor"
            ]
          },
          "selectedStroke": "6,#ff00ff,l",
          "height": 58,
          "fontSize": {
            "#ref": [
              "globalConfig.fontSize"
            ]
          }
        }
      },
      "expand": {
        "walletView": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.wallets.expandView"
          ]
        },
        "popularNBView": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.nb.expandView"
          ]
        },
        "cod": true
      },
      "nb": {
        "useGrid": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.nb.toggleGridView"
          ]
        },
        "popularBanksBanksHeader": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            false,
            true
          ]
        },
        "gridViewPadding": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            [
              15,
              8,
              8,
              8
            ],
            [
              8,
              8,
              8,
              8
            ]
          ]
        },
        "addMargin": false,
        "useV2": true,
        "mergeBanks": true,
        "showOtherBanksHeader": false
      },
      "upi": {
        "useGrid": {
          "#ref": [
            "masterConfig.controls.paymentOptions.dataOfElements.upi.toggleGridView"
          ]
        },
        "showAddUpiHeader": true,
        "addUpiButtonBottomDivider": true,
        "addUpiDividerHeightInSavedUpi": 0,
        "upiScreenArrangements": [
          "GenerateQR",
          "SavedVpa",
          "UpiAppsLayout",
          "AddUpiButton"
        ],
        "editTextLabelFontSize": {
          "#ref": [
            "masterConfig.components.inputFields.fieldName.fontSize"
          ]
        },
        "editTextLabelFontWeight": {
          "#js-expr": [
            "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
          ]
        }
      },
      "card": {
        "addCardButtonPosition": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            "withsaved",
            "bottom"
          ]
        },
        "addCardDividerHeightInSavedCards": 0,
        "addNewCardButtonAsListItem": true,
        "screenHeaderTextConfig": {
          "margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                28,
                10,
                0,
                10
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          }
        }
      },
      "sideBar.navbarItem.selectedStroke": {
        "#js-expr": [
          "var x = \"0,\";\nif(rc('masterConfig.desktopView.sideBar.removeSelectedStroke')==false)\n{\n  x = \"4,\";\n}\nx = x + rc('masterConfig.themes.Colors.primaryColor') +\n\",l\";\nx;"
        ]
      },
      "upiCollectViewType": "v3"
    },
    "masterConfig": {
      "themes": {
        "Colors": {
          "primaryColor": "#f4f4f4",
          "backgroundColor": "#F4F7FF",
          "errorColor": "#E55454",
          "successColor": "#53BB6F",
          "defaultTextColor": "#000000",
          "defaultTileColor": "#FFFFFF"
        },
        "TypoGraphy": {
          "fontBaseSize": 14,
          "desktopFontBaseSize": 16,
          "fontFamily": "PlusJakartaSans"
        },
        "Shadow": {
          "cardShadow": {
            "visible": false,
            "blur": 4,
            "yOffset": 1,
            "xOffset": 1,
            "spread": 0,
            "nativeShadow": 1,
            "color": "#E0E0E0"
          }
        }
      },
      "components": {
        "appBar": {
          "alignment": "Left",
          "leftIconSize": 20,
          "fillColor": {
            "#ref": [
              "masterConfig.themes.Colors.primaryColor"
            ]
          },
          "padding": [
            8,
            0,
            0,
            0
          ],
          "fontColor": "#2C2F3A",
          "fontSize": 18,
          "toolbarVisibility": true,
          "toolbarDividerVisibility": false,
          "useGradient": {
            "visible": false,
            "angle": 0,
            "colorValues": {
              "startColor": "#303D81",
              "endColor": "#318BAD"
            },
            "type": "linear"
          }
        },
        "OrderSummary": {
          "visible": true,
          "layout": "Layout 2",
          "backgroundColor": "#ffffff",
          "labelText": {
            "fontColor": "#454545",
            "fontSize": 14,
            "text": "Platform Subscription Fee",
            "fontWeight": "Regular",
            "rightText": "Fees payable"
          },
          "orderNameText": {
            "fontColor": "#454545",
            "fontSize": 14,
            "fontWeight": "SemiBold"
          },
          "amountText": {
            "fontColor": "#454545",
            "fontSize": 16,
            "fontWeight": "SemiBold"
          },
          "leftImage": {
            "url": "https://sandbox.assets.juspay.in/hyper/images/common/juspay_logo.png",
            "size": 16,
            "margin": [
              10,
              14,
              40,
              10
            ]
          },
          "amountbarDividerVisibility": true,
          "dividerColor": "#e5e7eb",
          "useGradient": {
            "visible": false,
            "angle": 0,
            "colorValues": {
              "startColor": "#303D81",
              "endColor": "#318BAD"
            },
            "type": "linear"
          }
        },
        "container": {
          "strokeColor": "#ffffff",
          "strokeWidth": 0,
          "cornerRadius": 0,
          "containerPadding": [
            0,
            24,
            0,
            40
          ],
          "cardMargin": 24,
          "cardPadding": 16
        },
        "sectionHeader": {
          "fontSize": 14,
          "fontColor": "#6D7280",
          "visible": true,
          "sectionHeaderPadding": [
            16,
            0,
            0,
            0
          ]
        },
        "listItems": {
          "height": 56,
          "paddings": [
            10,
            0,
            0,
            0
          ],
          "mainText": {
            "fontColor": {
              "#ref": [
                "masterConfig.themes.Colors.defaultTextColor"
              ]
            },
            "fontSize": {
              "#ref": [
                "masterConfig.themes.TypoGraphy.fontBaseSize"
              ]
            }
          },
          "subText": {
            "fontColor": "#4D4D4D",
            "fontSize": 12
          },
          "spacingBetween": 4,
          "primaryIconSize": 30,
          "secondaryIconSize": 18,
          "dividerColor": "#ffffff"
        },
        "grid": {
          "fontColor": {
            "#ref": [
              "masterConfig.themes.Colors.defaultTextColor"
            ]
          },
          "fontSize": 14,
          "iconSize": 32
        },
        "buttons": {
          "fontWeight": "SemiBold",
          "layout": "Indented",
          "fillColor": "#2C2F3A",
          "strokeColor": "#000000",
          "strokeWidth": "0",
          "strokeVisibility": false,
          "cornerRadius": 8,
          "fontColor": "#FCC32C",
          "fontSize": 16,
          "text": "Proceed to Pay ",
          "margin": [
            0,
            0,
            0,
            0
          ],
          "useGradient": {
            "visible": false,
            "angle": 20,
            "colorValues": {
              "startColor": "#303D81",
              "endColor": "#318BAD"
            },
            "type": "linear"
          }
        },
        "links": {
          "layout": "Regular",
          "buttonColor": "#ffffff",
          "buttonStroke": "1,#DDDDDD",
          "cornerRadius": 8,
          "fontColor": "#2194ff",
          "fontSize": 14,
          "leftMarginUpi": 22,
          "leftMarginNb": 2,
          "fullMarginUpi": [
            16,
            0,
            16,
            8
          ],
          "fullMarginNb": [
            16,
            0,
            16,
            8
          ]
        },
        "inputFields": {
          "cornerRadius": 8,
          "type": "box",
          "disabledStateColor": "#E9E9E9",
          "activeStateColor": "#2194ff",
          "upiVerifyTextColor": "#2194ff",
          "fieldName": {
            "fontWeight": "Bold",
            "fontColor": "#A7A7A7",
            "fontSize": 10,
            "padding": [
              4,
              0,
              4,
              0
            ]
          },
          "inputText": {
            "fontColor": {
              "#ref": [
                "masterConfig.themes.Colors.defaultTextColor"
              ]
            },
            "fontSize": 14,
            "padding": [
              18,
              1,
              18,
              1
            ]
          }
        },
        "searchBox": {
          "leftImage": {
            "size": 16,
            "margin": [
              6,
              0,
              6,
              0
            ]
          },
          "nonActiveState": {
            "strokeColor": "#B9BABE"
          },
          "padding": [
            12,
            0,
            12,
            0
          ]
        },
        "offers": {
          "visible": false,
          "banner": false,
          "rightIconType": true
        },
        "loader": {
          "height": 5
        }
      },
      "desktopView": {
        "OrderSummary": {
          "visible": true,
          "layout": "Layout 1",
          "backgroundColor": "#ffffff",
          "labelText": {
            "fontColor": "#999999",
            "fontSize": 12,
            "text": "abcd"
          },
          "orderNameText": {
            "fontColor": "#363636",
            "fontSize": 20
          },
          "amountText": {
            "fontColor": "#363636",
            "fontSize": 18
          },
          "leftImage": {
            "url": "https://sandbox.assets.juspay.in/hyper/images/common/juspay_logo.png",
            "size": 50,
            "visible": true,
            "margin": [
              10,
              10,
              10,
              10
            ]
          },
          "useGradient": {
            "visible": false,
            "angle": 0,
            "colorValues": {
              "startColor": "#303D81",
              "endColor": "#318BAD"
            },
            "type": "linear"
          }
        },
        "sideBar": {
          "selectedBackgroundColor": "#DBDBDB",
          "selectedTextColor": "#4B5563",
          "unSelectedTextColor": "#444549",
          "removeSelectedStroke": false
        },
        "icon": {
          "selectedColor": "#000000",
          "notSelectedColor": "#354052"
        }
      },
      "controls": {
        "paymentOptions": {
          "orderOfElements": [
            "upi"
          ],
          "dataOfElements": {
            "cards": {
              "credit": false,
              "debit": false,
              "mandates": true,
              "tokenizationConsentPopup": true
            },
            "upi": {
              "intent": true,
              "collect": true,
              "mandates": true,
              "upiIdValidation": true,
              "upiScanAndPay": false,
              "toggleGridView": false,
              "vpaSuggestionsLimit": 0
            },
            "nb": {
              "mandates": true,
              "toggleGridView": true,
              "expandView": true
            },
            "inApps": {
              "showCredEvenIfIneligible": true
            },
            "paylater": {
              "hideIneligiblePayLater": true
            },
            "emi": {
              "zestMoney": true
            },
            "cashod": {},
            "wallets": {
              "mandates": true,
              "expandView": true,
              "googlepay": false,
              "phonepeQcLite": false,
              "paytmInapp": false
            },
            "twidPay": {},
            "loanMarketplace": {}
          }
        },
        "features": {
          "nativeOTP": true,
          "quickPay": false,
          "outage": true,
          "showSavedVpas": true,
          "showSavedCards": true,
          "showExitPopup": false,
          "showPaymentStatusScreen": false,
          "enableTPV": false,
          "retryPayment": {
            "visible": true,
            "noOfAttempts": 3
          },
          "expiryTimer": {
            "visible": false,
            "showTimer": true,
            "activeTimeInMs": "900000"
          },
          "surcharge": {
            "visible": false,
            "surchargeOnButton": "Nothing",
            "surchargeOnAmountBar": "Nothing"
          }
        }
      }
    },
    "indeterminateLoaderConfig": {
      "#override": [
        "defaultLoaderConfig",
        {
          "loaderType": "ProgressBar",
          "text.visibility": "gone",
          "progressBar": {
            "background": {
              "#ref": [
                "screenConfig.bgPrimaryColor"
              ]
            },
            "color": {
              "#ref": [
                "globalConfig.primaryColor"
              ]
            },
            "width": "50",
            "height": {
              "#ref": [
                "masterConfig.components.loader.height"
              ]
            },
            "animation": {
              "scale": true,
              "translate": true,
              "scaleDuration": 400,
              "translateDuration": 1500,
              "scaleFrom": 1,
              "scaleTo": 2,
              "translateFrom": 0,
              "translateTo": 1,
              "repeatMode": "reverse",
              "repeatCount": {
                "type": "infinite",
                "value": ""
              },
              "interpolator": {
                "type": "Linear",
                "value": []
              }
            },
            "margin": [
              0,
              0,
              0,
              0
            ]
          }
        }
      ]
    },
    "defaultLoaderConfig": {
      "dot": {
        "background": "#ffffff"
      },
      "text": {
        "color": "#999999"
      },
      "height": 15,
      "loaderType": "ProgressBar"
    },
    "defaultPrestoList": {
      "padding": [
        0,
        0,
        0,
        0
      ],
      "height": 60,
      "margin": [
        {
          "#js-expr": [
            "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
          ]
        },
        0,
        {
          "#js-expr": [
            "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
          ]
        },
        0
      ],
      "font": {
        "#ref": [
          "globalConfig.fontRegular"
        ]
      },
      "textSize": {
        "#ref": [
          "masterConfig.components.listItems.mainText.fontSize"
        ]
      },
      "leftImage": {
        "size": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            40,
            {
              "#ref": [
                "masterConfig.components.listItems.primaryIconSize"
              ]
            }
          ]
        },
        "margin": [
          0,
          0,
          10,
          0
        ]
      },
      "rightImage": {
        "size": {
          "#ref": [
            "masterConfig.components.listItems.secondaryIconSize"
          ]
        }
      },
      "outageConfig": {
        "#override": [
          "defaultMessage",
          {
            "visibility": "gone",
            "text.text": "Bank is facing some issues. Try another option."
          }
        ]
      },
      "hasButton": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          true,
          true
        ]
      },
      "space": 16,
      "buttonPadding": {
        "#js-expr": [
          "var imageSize = rc('defaultPrestoList.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var\n  extras = 10; if (window.isDesktopView()){\n    extras = 10;\n    padding = 26;\n  } \n\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
        ]
      }
    },
    "upiOtherOptionsSecondaryButton": {
      "#override": [
        "defaultSecondaryButton",
        {
          "text.text": "Other UPI Options",
          "margin": {
            "#js-expr": [
              "var layout = rc('masterConfig.components.links.layout')\nif(layout == \"Regular\" || layout == \"Centered\") [rc('masterConfig.components.links.leftMarginUpi'), 0, 0, 8]; else if(layout == \"Button\") rc('masterConfig.components.links.fullMarginUpi');"
            ]
          },
          "text.color": {
            "#ref": [
              "masterConfig.components.links.fontColor"
            ]
          },
          "text.padding": [
            0,
            2,
            4,
            2
          ],
          "height": 30
        }
      ]
    },
    "nbOtherBanksSecondaryButton": {
      "#override": [
        "defaultSecondaryButton",
        {
          "text.text": "Other Banks",
          "margin": {
            "#js-expr": [
              "var layout = rc('masterConfig.components.links.layout')\nif(layout == \"Regular\" || layout == \"Centered\") [rc('masterConfig.components.links.leftMarginNb'), 0, 0, 8]; else if(layout == \"Button\") rc('masterConfig.components.links.fullMarginNb');"
            ]
          },
          "text.color": {
            "#ref": [
              "masterConfig.components.links.fontColor"
            ]
          },
          "text.padding": [
            0,
            2,
            4,
            2
          ],
          "height": 30
        }
      ]
    },
    "defaultSecondaryButton": {
      "#override": [
        "defaultPrimaryButton",
        {
          "width": {
            "#js-expr": [
              "var layout = rc('masterConfig.components.links.layout')\nif(layout == \"Regular\") 130; else if(layout == \"Centered\" || layout == \"Button\") 'match_parent';"
            ]
          },
          "cornerRadius": {
            "#ref": [
              "masterConfig.components.links.cornerRadius"
            ]
          },
          "translation": 0,
          "margin": [
            0,
            0,
            0,
            0
          ],
          "stroke": {
            "#js-expr": [
              "var layout=rc('masterConfig.components.links.layout')\nif(layout == \"Button\"){\n  rc('masterConfig.components.links.buttonStroke')\n}else {\n'0,#ffffff'\n}"
            ]
          },
          "color": {
            "#js-expr": [
              "var layout=rc('masterConfig.components.links.layout')\nif(layout == \"Regular\"){\n  rc('masterConfig.themes.Colors.defaultTileColor')\n}else if(layout == \"Centered\" || layout == \"Button\"){\n  rc('masterConfig.components.links.buttonColor')\n}"
            ]
          },
          "text.color": {
            "#ref": [
              "globalConfig.primaryColor"
            ]
          },
          "text.size": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              {
                "#ref": [
                  "globalConfig.fontSize"
                ]
              },
              {
                "#js-expr": [
                  "var size = rc('masterConfig.components.links.fontSize');\n      size;"
                ]
              }
            ]
          },
          "text.font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          }
        }
      ]
    },
    "EmiPopup": {
      "#override": [
        "defaultPopup",
        {
          "padding": [
            20,
            24,
            20,
            24
          ],
          "useList": false,
          "useBullets": true,
          "bulletIconUrl": "https://assets.juspay.in/hyper/images/common/bullet.png",
          "overlayBackground": "#AA000000",
          "corners": [
            8,
            true,
            true,
            false,
            false
          ],
          "background": {
            "#ref": [
              "screenConfig.uiCard.color"
            ]
          },
          "header.headerSize": 22,
          "header.headerColor": "#595959",
          "header.headerFont": {
            "#ref": [
              "globalConfig.fontBold"
            ]
          },
          "header.headerPadding": [
            0,
            0,
            0,
            0
          ],
          "header.headerMargin": [
            0,
            0,
            0,
            0
          ],
          "header.headerImageUrl": "https://assets.juspay.in/hyper/images/common/cross.png",
          "contentTextSize": {
            "#ref": [
              "globalConfig.fontSize"
            ]
          },
          "dividerVisibility": "GONE",
          "checkBoxVisibility": "GONE",
          "termsVisibility": "GONE",
          "buttonLayoutConfig.buttonHeight": 44,
          "buttonLayoutConfig.buttonsViewMargin": [
            0,
            32,
            0,
            0
          ],
          "buttonLayoutConfig.brandViewVisibility": "GONE",
          "buttonLayoutConfig.buttonOne.text": "Yes",
          "buttonLayoutConfig.buttonOne.stroke": "1,#5A68E7",
          "buttonLayoutConfig.buttonOne.textColor": {
            "#ref": [
              "globalConfig.primaryColor"
            ]
          },
          "buttonLayoutConfig.buttonOne.textSize": {
            "#ref": [
              "globalConfig.fontSizeLarge"
            ]
          },
          "buttonLayoutConfig.buttonOne.textFont": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "buttonLayoutConfig.buttonOne.cornerRadius": 100,
          "buttonLayoutConfig.buttonTwo.text": "No",
          "buttonLayoutConfig.buttonTwo.translation": 0,
          "buttonLayoutConfig.buttonTwo.textSize": {
            "#ref": [
              "globalConfig.fontSizeLarge"
            ]
          },
          "buttonLayoutConfig.buttonTwo.textFont": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "buttonLayoutConfig.buttonTwo.cornerRadius": 100,
          "overlayVisibility": "VISIBLE"
        }
      ]
    },
    "defaultAddCard": {
      "cardConfig": {
        "padding": {
          "#js-expr": [
            " var hP = rc('screenConfig.uiCard.horizontalPadding');\n        var vP = rc('screenConfig.uiCard.verticalPadding');\n        if (window.isDesktopView()) {\n          [11, 0, 0, 0]\n        } else {\n          [hP, vP, hP, vP + 12]\n        }\n      "
          ]
        },
        "cornerRadius": {
          "#js-expr": [
            " var hP = rc('screenConfig.containerAttribs.horizontalSpacing');\n        if (hP == 0) {\n          rc('masterConfig.components.container.cornerRadius')\n        } else {\n          rc('masterConfig.components.container.cornerRadius')\n        }\n      "
          ]
        }
      },
      "cardNumber": {
        "labelConfig": {
          "textFont": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "textColor": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontColor"
            ]
          },
          "textSize": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontSize"
            ]
          },
          "padding": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.padding"
            ]
          }
        },
        "editTextConfig": {
          "#override": [
            "cardNumberConfig",
            {
              "input.height": 48,
              "icon.width": 26,
              "icon.height": 26
            }
          ]
        },
        "inputFieldMargin": {
          "#js-expr": [
            "var topMargin = 8;\nvar bottomMargin = 20;\n                  bottomMargin = (window.__OS.toLowerCase() === \"ios\") ? bottomMargin - 20 : bottomMargin;\n                  if(window.isAndroid()){\n                    bottomMargin = bottomMargin - 20;\n                  }\n                  topMargin = (window.__OS.toLowerCase() === \"ios\") ? topMargin - 8 : topMargin;\n                  if(window.isAndroid()){\n                    topMargin = topMargin - 8;\n                  }\n      [0, topMargin, 0, bottomMargin];"
          ]
        }
      },
      "expiry": {
        "labelConfig": {
          "textFont": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "textColor": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontColor"
            ]
          },
          "textSize": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontSize"
            ]
          },
          "padding": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.padding"
            ]
          }
        },
        "editTextConfig": {
          "#override": [
            "expiryDateConfig",
            {
              "icon.visibility": "gone",
              "input.height": 48
            }
          ]
        }
      },
      "cvv": {
        "labelConfig": {
          "textFont": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "textColor": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontColor"
            ]
          },
          "textSize": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.fontSize"
            ]
          },
          "padding": {
            "#ref": [
              "masterConfig.components.inputFields.fieldName.padding"
            ]
          }
        },
        "editTextConfig": {
          "#override": [
            "cvvConfig",
            {
              "input.height": 48
            }
          ]
        }
      },
      "saveCard": {
        "text": "Securely save this card for future payments.",
        "textSize": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            13,
            {
              "#ref": [
                "globalConfig.fontSizeSmall"
              ]
            }
          ]
        },
        "textFont": {
          "#ref": [
            "globalConfig.fontRegular"
          ]
        },
        "margin": {
          "#js-expr": [
            "var topMargin = 10;\n                  topMargin = (window.__OS.toLowerCase() === \"ios\") ? topMargin - 10 : topMargin;\n                  if(window.isAndroid()){\n                    topMargin = topMargin - 10;\n                  }\n      [0, topMargin, 0, 0];"
          ]
        },
        "infoIcon": {
          "visible": false
        }
      },
      "si": {
        "textFont": {
          "#ref": [
            "globalConfig.fontRegular"
          ]
        },
        "checkboxVisibility": "visible"
      },
      "enforceCard": {
        "textFont": {
          "#ref": [
            "globalConfig.fontRegular"
          ]
        },
        "checkBoxImage": "https://assets.juspay.in/juspay/assets/images/saved_card_lock.png"
      },
      "warningMessage": {
        "textFont": {
          "#ref": [
            "globalConfig.fontBold"
          ]
        }
      },
      "payButtonConfig": {
        "#override": [
          "defaultPrimaryButton",
          {
            "margin": {
              "#if": [
                {
                  "#js-expr": [
                    "window.isDesktopView()"
                  ]
                },
                [
                  0,
                  6,
                  0,
                  0
                ],
                {
                  "#js-expr": [
                    "var containerPadding = rc('masterConfig.components.container.containerPadding');\n                  var buttonPadding = rc('masterConfig.components.buttons.margin');\n                  var leftPadding = containerPadding[0] + buttonPadding[0];\n                  var topPadding = buttonPadding[1];\n                  var rightPadding = containerPadding[2] + buttonPadding[2];\n                  var bottomPadding = buttonPadding[3];\n                  [leftPadding, topPadding + 10, rightPadding, bottomPadding + 10];"
                  ]
                }
              ]
            },
            "width": {
              "#if": [
                {
                  "#js-expr": [
                    "window.isDesktopView()"
                  ]
                },
                250,
                "match_parent"
              ]
            }
          }
        ]
      },
      "cardConfig.margin": {
        "#js-expr": [
          "var vP = rc('screenConfig.containerAttribs.verticalSpacing');\n                  var tM = rc('screenConfig.utils.translationMargin');\n                  var containerPadding =\n                  rc('masterConfig.components.container.containerPadding');\n                        var l = containerPadding[0];\n                        var t= containerPadding[1];\n                        var r = containerPadding[2];\n                        var b = rc('masterConfig.components.container.cardMargin');\n                  window.isDesktopView() ? [16, vP, tM, vP] :  [l,t,r,b]"
        ]
      },
      "placeBtnInCard": true
    },
    "defaultNavBar": {
      "background": "#F8F8F8",
      "textSize": {
        "#js-expr": [
          "rc('globalConfig.fontSize') - 1"
        ]
      },
      "selectedBackground": "#ffffff"
    },
    "nbScreenSearchBox": {
      "#override": [
        "defaultSearchBox",
        {
          "stroke": {
            "#js-expr": [
              "var strokeColor = rc('masterConfig.components.searchBox.nonActiveState.strokeColor');\n\"1,\"+strokeColor"
            ]
          }
        }
      ]
    },
    "defaultSearchBox": {
      "leftImage": {
        "size": {
          "#ref": [
            "masterConfig.components.searchBox.leftImage.size"
          ]
        },
        "margin": {
          "#ref": [
            "masterConfig.components.searchBox.leftImage.margin"
          ]
        }
      },
      "stroke": {
        "#ref": [
          "defaultEditText.stroke"
        ]
      },
      "height": 48,
      "padding": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          [
            5,
            4,
            10,
            0
          ],
          {
            "#ref": [
              "masterConfig.components.searchBox.padding"
            ]
          }
        ]
      },
      "margin": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          [
            0,
            0,
            0,
            0
          ],
          [
            16,
            0,
            16,
            0
          ]
        ]
      },
      "cornerRadius": {
        "#ref": [
          "defaultEditText.cornerRadius"
        ]
      }
    },
    "defaultGridItem": {
      "padding": [
        0,
        8,
        0,
        8
      ],
      "background": {
        "#ref": [
          "masterConfig.themes.Colors.defaultTileColor"
        ]
      },
      "margin": [
        8,
        0,
        8,
        0
      ],
      "image": {
        "size": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            40,
            {
              "#ref": [
                "masterConfig.components.grid.iconSize"
              ]
            }
          ]
        }
      },
      "text": {
        "size": {
          "#ref": [
            "masterConfig.components.grid.fontSize"
          ]
        },
        "color": {
          "#ref": [
            "masterConfig.components.grid.fontColor"
          ]
        }
      }
    },
    "upiScreenEditText": {
      "#override": [
        "defaultEditText",
        {
          "icon.textColor": {
            "#ref": [
              "masterConfig.components.inputFields.upiVerifyTextColor"
            ]
          },
          "header.color": {
            "#ref": [
              "masterConfig.components.inputFields.activeStateColor"
            ]
          },
          "input.padding": [
            10,
            0,
            10,
            0
          ]
        }
      ]
    },
    "verifyOtpEditText": {
      "#override": [
        "defaultEditText",
        {
          "icon.height": 25,
          "icon.textVisibility": "visible",
          "icon.visibility": "visible",
          "icon.text": "Resend OTP",
          "icon.textColor": {
            "#ref": [
              "masterConfig.themes.Colors.primaryColor"
            ]
          },
          "header.text": "OTP",
          "input.inpType": "Numeric",
          "input.textMargin": [
            12,
            0,
            12,
            0
          ],
          "focus": true,
          "input.textSize": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              20,
              {
                "#ref": [
                  "globalConfig.fontSizeLarge"
                ]
              }
            ]
          },
          "margin": [
            10,
            10,
            0,
            12
          ],
          "header.color": {
            "#ref": [
              "masterConfig.components.inputFields.activeStateColor"
            ]
          }
        }
      ]
    },
    "verifyNumberEditText": {
      "#override": [
        "defaultEditText",
        {
          "input.pattern": "^[0-9]+$,10",
          "input.inpType": "Numeric",
          "input.textMargin": [
            12,
            0,
            12,
            0
          ],
          "focus": true,
          "input.textSize": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              20,
              {
                "#ref": [
                  "globalConfig.fontSizeLarge"
                ]
              }
            ]
          },
          "header.color": {
            "#ref": [
              "masterConfig.components.inputFields.activeStateColor"
            ]
          }
        }
      ]
    },
    "defaultEditText": {
      "margin": [
        10,
        10,
        0,
        20
      ],
      "useMaterialView": {
        "#if": [
          {
            "#eq": [
              {
                "#ref": [
                  "masterConfig.components.inputFields.type"
                ]
              },
              "materialView"
            ]
          },
          true,
          false
        ]
      },
      "cornerRadius": {
        "#js-expr": [
          "var radius = rc('masterConfig.components.inputFields.cornerRadius');\nvar height = rc('defaultPrimaryButton.height');\nvar val = height/2;\nif(val <= radius){\n  radius = val;\n}\n                  radius"
        ]
      },
      "stroke": {
        "#if": [
          {
            "#eq": [
              {
                "#ref": [
                  "masterConfig.components.inputFields.type"
                ]
              },
              "underline"
            ]
          },
          "",
          {
            "#js-expr": [
              "var color = rc('masterConfig.components.inputFields.disabledStateColor');\n          \"1,\" + color"
            ]
          }
        ]
      },
      "header": {
        "color": {
          "#ref": [
            "masterConfig.components.inputFields.fieldName.fontColor"
          ]
        },
        "size": {
          "#if": [
            {
              "#js-expr": [
                "window.isAndroid()"
              ]
            },
            {
              "#ref": [
                "masterConfig.components.inputFields.fieldName.fontSize"
              ]
            },
            {
              "#ref": [
                "masterConfig.components.inputFields.fieldName.fontSize"
              ]
            }
          ]
        },
        "padding": {
          "#ref": [
            "masterConfig.components.inputFields.fieldName.padding"
          ]
        },
        "font": {
          "#js-expr": [
            "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.inputFields.fieldName.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
          ]
        }
      },
      "icon": {
        "width": {
          "#js-expr": [
            "rc('globalConfig.iconSize') - 20"
          ]
        },
        "height": {
          "#js-expr": [
            "rc('globalConfig.iconSize') - 20"
          ]
        },
        "textColor": {
          "#ref": [
            "globalConfig.primaryColor"
          ]
        }
      },
      "lineSeparator": {
        "color": {
          "#ref": [
            "masterConfig.components.inputFields.disabledStateColor"
          ]
        },
        "focusedColor": {
          "#ref": [
            "masterConfig.components.inputFields.activeStateColor"
          ]
        }
      },
      "input": {
        "padding": {
          "#js-expr": [
            "  var padding = rc('masterConfig.components.inputFields.inputText.padding');\n            if(rc('masterConfig.components.inputFields.type') == 'underline'){\n              padding[0] = padding[0] - 18;\n            }\n            padding;"
          ]
        },
        "height": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            48,
            48
          ]
        },
        "font": {
          "#ref": [
            "globalConfig.fontSemiBold"
          ]
        },
        "width": {
          "#if": [
            {
              "#js-expr": [
                "window.isDesktopView()"
              ]
            },
            399,
            "match_parent"
          ]
        },
        "textColor": {
          "#ref": [
            "masterConfig.components.inputFields.inputText.fontColor"
          ]
        },
        "textSize": {
          "#ref": [
            "masterConfig.components.inputFields.inputText.fontSize"
          ]
        }
      },
      "useMaterialView:'#if'": [
        {
          "#eq": [
            {
              "#ref": [
                "masterConfig.components.inputFields.type"
              ]
            },
            "materialView"
          ]
        },
        true,
        false
      ],
      "labelTextPadding": {
        "#js-expr": [
          "  var padding = rc('masterConfig.components.inputFields.fieldName.padding');\n            if(rc('masterConfig.components.inputFields.type') == 'underline'){\n              padding[0] = padding[0] - 5;\n            }\n            padding;"
        ]
      },
      "labelTextColor": {
        "#ref": [
          "masterConfig.components.inputFields.fieldName.fontColor"
        ]
      }
    },
    "addScreenSurcharge": {
      "#override": [
        "defaultMessage",
        {
          "background": "#F5F6F8",
          "text.size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "text.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "width": "WRAP_CONTENT",
          "text.text": "Convenience fee applicable",
          "visibility": "VISIBLE",
          "padding": [
            6,
            6,
            0,
            6
          ],
          "text.margin": [
            6,
            0,
            6,
            0
          ]
        }
      ]
    },
    "offersPreviewTermsAndConditions": {
      "#override": [
        "defaultMessage",
        {
          "padding": {
            "#js-expr": [
              "var topViewPadding = rc(\"defaultListItem.topView.padding\");\n              var topViewMargin = rc(\"defaultListItem.topView.margin\");\n              var padding = [];\n              padding[0] = topViewPadding[0] + topViewMargin[0];\n              padding[1] = padding[2] = 0;\n              padding[3] = 5;\n              padding\n            "
            ]
          },
          "text.useHTMLForText": true,
          "visibility": "VISIBLE",
          "margin": [
            0,
            0,
            0,
            10
          ],
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.margin": [
            0,
            0,
            0,
            0
          ],
          "text.padding": [
            0,
            0,
            0,
            0
          ],
          "width": "MATCH_PARENT",
          "maxWidth": 500,
          "text.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          }
        }
      ]
    },
    "offersNudgeConfig": {
      "#override": [
        "defaultMessage",
        {
          "padding": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 6];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 6]        "
            ]
          },
          "text.size": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "text.color": {
            "#js-expr": [
              "var textPrimaryColor = rc(\"globalConfig.textPrimaryColor\");\n              var hexlessCode = textPrimaryColor.split(\"#\")[1];\n              if (hexlessCode)\n                \"#50\" + hexlessCode;\n              else textPrimaryColor;\n            "
            ]
          },
          "background": "",
          "text.margin": [
            0,
            0,
            0,
            0
          ],
          "isClickable": false
        }
      ]
    },
    "credOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": 12,
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
            ]
          }
        }
      ]
    },
    "cardsOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding');\nvar extras = 12;\nif (window.isDesktopView()){\n  extras = 18;\n  padding = 20;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, padding]; else if(buttonLayout == 'Stretched') [padding, 0, padding, padding]"
            ]
          }
        }
      ]
    },
    "upiHomeScreenOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
            ]
          }
        }
      ]
    },
    "gridOutageMessage": {
      "#override": [
        "defaultOutageMessage",
        {
          "text.color": {
            "#ref": [
              "globalConfig.errorColor"
            ]
          },
          "text.margin": [
            26,
            5,
            20,
            10
          ],
          "text.size": 13,
          "text.useHTMLForText": false,
          "maxWidth": 700
        }
      ]
    },
    "nbScreenOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultPrestoList.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var\n  extras = 10; if (window.isDesktopView()){\n    extras = 10;\n    padding = 26;\n  } \n\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
            ]
          }
        }
      ]
    },
    "nbScreenSurchargeMessage": {
      "#override": [
        "defaultMessage",
        {
          "background": "#F5F6F8",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "width": "WRAP_CONTENT",
          "text.text": "Convenience fee applicable",
          "visibility": "VISIBLE",
          "padding": [
            6,
            6,
            0,
            6
          ],
          "text.margin": [
            6,
            0,
            6,
            0
          ],
          "margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 6];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 6]        "
            ]
          }
        }
      ]
    },
    "offerMessage": {
      "#override": [
        "defaultMessage",
        {
          "isClickable": true,
          "background": "",
          "padding": [
            0,
            0,
            0,
            0
          ],
          "margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 6];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 6]        "
            ]
          },
          "gravity": "CENTER_VERTICAL",
          "image.size": {
            "#ref": [
              "globalConfig.fontSize"
            ]
          },
          "image.margin": [
            0,
            0,
            4,
            0
          ],
          "image.visibility": "gone",
          "text.color": "#0A8F67",
          "text.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "text.size": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "text.margin": [
            0,
            0,
            6,
            0
          ],
          "text.useHTMLForText": true,
          "text.gravity": "CENTER_VERTICAL"
        }
      ]
    },
    "gridSurchargeMessage": {
      "#override": [
        "defaultMessage",
        {
          "background": "#F5F6F8",
          "text.size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "text.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "width": "WRAP_CONTENT",
          "text.text": "Convenience fee applicable",
          "visibility": "VISIBLE",
          "padding": [
            0,
            6,
            0,
            6
          ],
          "text.margin": [
            6,
            0,
            6,
            0
          ],
          "margin": [
            18,
            0,
            10,
            0
          ]
        }
      ]
    },
    "quickPayOutage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.margin": [
            0,
            0,
            0,
            0
          ]
        }
      ]
    },
    "upiOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.margin": [
            0,
            5,
            0,
            0
          ]
        }
      ]
    },
    "walletOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": 12,
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
            ]
          }
        }
      ]
    },
    "ppOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "cornerRadius": 0,
          "text.color": {
            "#ref": [
              "masterConfig.themes.Colors.errorColor"
            ]
          },
          "text.text": "Please try another payment method, experiencing payment failures for SBI Bank.",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 4];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 4]"
            ]
          }
        }
      ]
    },
    "nbMandateConsentMessage": {
      "#override": [
        "defaultMessage",
        {
          "text.size": 12,
          "text.color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "text.margin": [
            5,
            0,
            0,
            5
          ],
          "text.useHTMLForText": true,
          "image.visibility": "visible",
          "image.url": "https://assets.juspay.in/hyper/assets/in.juspay.merchants/images/defaultclient/mandate_required_2023_06_02_16_37_49.png",
          "image.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                25,
                0,
                0,
                0
              ],
              [
                5,
                0,
                0,
                0
              ]
            ]
          },
          "image.size": 16,
          "gravity": "START"
        }
      ]
    },
    "rewardsPayMessage": {
      "#override": [
        "defaultMessage",
        {
          "text.color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "text.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 4, padding, 6];  else if(buttonLayout == 'Stretched') [padding, 4, padding, 6]"
            ]
          }
        }
      ]
    },
    "defaultMessage": {
      "visibility": "VISIBLE",
      "maxwidth": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          600,
          300
        ]
      },
      "text": {
        "color": {
          "#ref": [
            "masterConfig.themes.Colors.errorColor"
          ]
        },
        "margin": {
          "#js-expr": [
            "var imageSize = rc('defaultListItem.topView.leftImage.size');\n      var pX = rc('screenConfig.uiCard.horizontalPadding') - 6;\n      if (window.isDesktopView()) pX = 13;\n      var space = pX + imageSize;\n      var buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space + 16, 0, pX, 0]; else if(buttonLayout == 'Stretched') [0, 0, pX, 0]"
          ]
        },
        "size": {
          "#ref": [
            "masterConfig.components.listItems.subText.fontSize"
          ]
        }
      }
    },
    "surchargeMessage": {
      "#override": [
        "defaultMessage",
        {
          "background": "#F5F6F8",
          "text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "text.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "width": "match_parent",
          "text.text": "Convenience fee applicable",
          "visibility": "VISIBLE",
          "maxWidth": 300,
          "padding": [
            0,
            6,
            0,
            6
          ],
          "text.margin": [
            6,
            0,
            6,
            0
          ],
          "margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 6];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 6]        "
            ]
          }
        }
      ]
    },
    "paymentInfoMessage": {
      "#override": [
        "defaultMessage",
        {
          "visibility": "GONE"
        }
      ]
    },
    "walletPrimaryButton": {
      "#override": [
        "defaultPrimaryButton",
        {
          "margin": [
            0,
            20,
            0,
            0
          ]
        }
      ]
    },
    "upiScreenPrimaryButton": {
      "#override": [
        "defaultPrimaryButton",
        {
          "margin": [
            0,
            10,
            0,
            0
          ]
        }
      ]
    },
    "nbPrimaryButton": {
      "#override": [
        "defaultPrimaryButton",
        {
          "margin": {
            "#js-expr": [
              "if (window.isDesktopView()) {\n        var cardPadding = rc('masterConfig.components.container.cardPadding');\n        var val = 10 + cardPadding;\n        [0, 0, 0,25]\n      } else {\n        var padding = rc('masterConfig.components.buttons.margin');\n        \n        padding;\n       }   "
            ]
          }
        }
      ]
    },
    "defaultPrimaryButton": {
      "color": {
        "#ref": [
          "masterConfig.components.buttons.fillColor"
        ]
      },
      "width": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          272,
          "match_parent"
        ]
      },
      "height": 48,
      "cornerRadius": {
        "#ref": [
          "masterConfig.components.buttons.cornerRadius"
        ]
      },
      "margin": {
        "#js-expr": [
          "if (window.isDesktopView()) {\n        [0, 10, 0,0]\n      } else {\n        rc('masterConfig.components.buttons.margin');\n        }"
        ]
      },
      "stroke": {
        "#js-expr": [
          "var strokeColor = rc('masterConfig.components.buttons.strokeColor');\n                  var strokeWidth = rc('masterConfig.components.buttons.strokeWidth');\n                  var isVisible = rc('masterConfig.components.buttons.strokeVisibility');\n                  isVisible == false ? '' : strokeWidth+\",\"+strokeColor"
        ]
      },
      "text": {
        "text": {
          "#ref": [
            "masterConfig.components.buttons.text"
          ]
        },
        "color": {
          "#ref": [
            "masterConfig.components.buttons.fontColor"
          ]
        },
        "size": {
          "#ref": [
            "masterConfig.components.buttons.fontSize"
          ]
        },
        "font": {
          "#js-expr": [
            "var fonts = rc('globalConfig.fontBold');\nif(rc('masterConfig.components.buttons.fontWeight') == 'Regular')\n{\n  fonts = rc('globalConfig.fontRegular')\n}\nif(rc('masterConfig.components.buttons.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
          ]
        }
      },
      "secondaryText": {
        "text": "",
        "color": "#FFFFFF",
        "size": 8,
        "margin": [
          0,
          2,
          0,
          0
        ],
        "padding": [
          0,
          0,
          0,
          0
        ],
        "gravity": "CENTER",
        "useTextFromHtml": false,
        "font": {
          "#ref": [
            "globalConfig.fontRegular"
          ]
        }
      },
      "useGradient": {
        "#ref": [
          "masterConfig.components.buttons.useGradient.visible"
        ]
      },
      "gradient": {
        "angle": {
          "#ref": [
            "masterConfig.components.buttons.useGradient.angle"
          ]
        },
        "values": [
          {
            "#ref": [
              "masterConfig.components.buttons.useGradient.colorValues.endColor"
            ]
          },
          {
            "#ref": [
              "masterConfig.components.buttons.useGradient.colorValues.startColor"
            ]
          }
        ],
        "type": {
          "#ref": [
            "masterConfig.components.buttons.useGradient.type"
          ]
        }
      }
    },
    "ppAmountBar": {
      "#override": [
        "defaultAmountBar",
        {
          "visibility": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.components.OrderSummary.visible"
                ]
              },
              "VISIBLE",
              "GONE"
            ]
          }
        }
      ]
    },
    "defaultWebAmountBar": {
      "padding": [
        16,
        8,
        16,
        8
      ],
      "percentWidth": true,
      "width": 94,
      "height": 85,
      "leftSection": {
        "image": {
          "url": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.leftImage.url"
            ]
          },
          "visibility": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.desktopView.OrderSummary.leftImage.visible"
                ]
              },
              "VISIBLE",
              "GONE"
            ]
          },
          "height": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.leftImage.size"
            ]
          },
          "width": {
            "#js-expr": [
              "var height = rc('masterConfig.desktopView.OrderSummary.leftImage.size'); var width = height+65; width;"
            ]
          },
          "usePackageIcon": false,
          "margin": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.leftImage.margin"
            ]
          },
          "padding": [
            0,
            0,
            0,
            0
          ],
          "cornerRadius": 5
        },
        "text": ""
      },
      "lineItems": {
        "#js-expr": [
          "var layout= rc('masterConfig.desktopView.OrderSummary.layout')\nif(layout == \"Layout 1\"){\n  rc('desktopLineItems1')\n}else if(layout == \"Layout 2\"){\n  rc('desktopLineItems2')\n}else if(layout == \"Layout 3\"){\n  rc('desktopLineItems3')\n}else{\n  rc('desktopLineItems4')\n}"
        ]
      },
      "translation": {
        "#if": [
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.visible"
            ]
          },
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.nativeShadow"
            ]
          },
          0
        ]
      },
      "background": {
        "#ref": [
          "masterConfig.desktopView.OrderSummary.backgroundColor"
        ]
      },
      "visibility": {
        "#if": [
          {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.visible"
            ]
          },
          "VISIBLE",
          "GONE"
        ]
      },
      "useGradient": {
        "#ref": [
          "masterConfig.desktopView.OrderSummary.useGradient.visible"
        ]
      },
      "gradient": {
        "angle": {
          "#ref": [
            "masterConfig.desktopView.OrderSummary.useGradient.angle"
          ]
        },
        "values": [
          {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.useGradient.colorValues.endColor"
            ]
          },
          {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.useGradient.colorValues.startColor"
            ]
          }
        ],
        "type": {
          "#ref": [
            "masterConfig.desktopView.OrderSummary.useGradient.type"
          ]
        }
      }
    },
    "defaultAmountBar": {
      "padding": [
        0,
        0,
        0,
        0
      ],
      "rightSection": {
        "size": {
          "#ref": [
            "masterConfig.components.OrderSummary.amountText.fontSize"
          ]
        },
        "color": {
          "#ref": [
            "masterConfig.components.OrderSummary.amountText.fontColor"
          ]
        },
        "visibility": {
          "#js-expr": [
            "var layout = rc('masterConfig.components.OrderSummary.layout')\n\nif(layout === 'Layout 3') 'visible'; \nelse 'gone'; "
          ]
        },
        "font": {
          "#js-expr": [
            "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
          ]
        }
      },
      "lineItems": {
        "#js-expr": [
          "var layout=rc('masterConfig.components.OrderSummary.layout')\nif(layout == \"Layout 1\"){\n  rc('lineItems1')\n}else if(layout == \"Layout 2\"){\n  rc('lineItems2')\n}else if(layout == \"Layout 3\"){\n  rc('lineItems3')\n}else if(layout == \"Layout 4\"){\n  rc('lineItems4')\n}else{\n  rc('lineItems5')\n}"
        ]
      },
      "translation": {
        "#if": [
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.visible"
            ]
          },
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.nativeShadow"
            ]
          },
          0
        ]
      },
      "background": {
        "#ref": [
          "masterConfig.components.OrderSummary.backgroundColor"
        ]
      },
      "dividerColor": {
        "#ref": [
          "masterConfig.components.OrderSummary.dividerColor"
        ]
      },
      "dividerVisibility": {
        "#if": [
          {
            "#eq": [
              {
                "#ref": [
                  "masterConfig.components.OrderSummary.amountbarDividerVisibility"
                ]
              },
              true
            ]
          },
          "visible",
          "gone"
        ]
      },
      "useGradient": {
        "#ref": [
          "masterConfig.components.OrderSummary.useGradient.visible"
        ]
      },
      "gradient": {
        "angle": {
          "#ref": [
            "masterConfig.components.OrderSummary.useGradient.angle"
          ]
        },
        "values": [
          {
            "#ref": [
              "masterConfig.components.OrderSummary.useGradient.colorValues.endColor"
            ]
          },
          {
            "#ref": [
              "masterConfig.components.OrderSummary.useGradient.colorValues.startColor"
            ]
          }
        ],
        "type": {
          "#ref": [
            "masterConfig.components.OrderSummary.useGradient.type"
          ]
        }
      }
    },
    "upiAddToolbar": {
      "#override": [
        "defaultToolbar",
        {
          "background": {
            "#js-expr": [
              "let useGradient = rc('masterConfig.components.appBar.useGradient.visible');\nlet isDesktopView = window.isDesktopView();\n\nif(useGradient) '#00ffffff';\nelse if(isDesktopView) '#ffffff';\n      else rc('masterConfig.components.appBar.fillColor')"
            ]
          }
        }
      ]
    },
    "webBackToolBar": {
      "#override": [
        "webPaymentHeaderToolbar",
        {
          "background": "#ffffff",
          "textSize": {
            "#js-expr": [
              "rc('globalConfig.fontSize')"
            ]
          },
          "leftIcon.visibility": "Visible",
          "visibility": "VISIBLE",
          "divider.visibility": "VISIBLE",
          "leftIcon.size": 16,
          "contentMargin": [
            25,
            0,
            0,
            0
          ]
        }
      ]
    },
    "webPaymentHeaderToolbar": {
      "#override": [
        "defaultToolbar",
        {
          "background": {
            "#ref": [
              "screenConfig.bgPrimaryColor"
            ]
          },
          "textSize": {
            "#js-expr": [
              "rc('globalConfig.fontSize') + 4"
            ]
          },
          "leftIcon.visibility": "GONE",
          "text": "Payment Methods",
          "visibility": "VISIBLE",
          "textGravity": "left",
          "useGradient": false
        }
      ]
    },
    "quickPayToolbar": {
      "#override": [
        "defaultToolbar",
        {
          "visibility": "GONE"
        }
      ]
    },
    "webAddButtonToolbar": {
      "#override": [
        "defaultToolbar",
        {
          "text": "Add New Card",
          "background": {
            "#ref": [
              "screenConfig.uiCard.color"
            ]
          },
          "textSize": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "height": 52,
          "useGradient": false,
          "useBackgroundImage": false,
          "textColor": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "contentMargin": [
            27,
            0,
            0,
            0
          ],
          "padding": [
            29,
            10,
            24,
            10
          ],
          "divider.visibility": "gone",
          "leftIcon.size": 22,
          "leftIcon.visibility": "VISIBLE"
        }
      ]
    },
    "defaultToolbar": {
      "divider": {
        "color": "#dddddd",
        "visibility": {
          "#if": [
            {
              "#eq": [
                {
                  "#ref": [
                    "masterConfig.components.appBar.toolbarDividerVisibility"
                  ]
                },
                true
              ]
            },
            "visible",
            "gone"
          ]
        },
        "height": 1
      },
      "background": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          "#ffffff",
          {
            "#ref": [
              "masterConfig.components.appBar.fillColor"
            ]
          }
        ]
      },
      "text": "Payment Methods",
      "textColor": {
        "#if": [
          {
            "#js-expr": [
              "window.isDesktopView()"
            ]
          },
          {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          {
            "#ref": [
              "masterConfig.components.appBar.fontColor"
            ]
          }
        ]
      },
      "textSize": {
        "#js-expr": [
          "var size = rc('masterConfig.components.appBar.fontSize');\n                  size = (window.__OS.toLowerCase() === \"ios\") ? size + 2 : size;\n                  if(window.isAndroid()){\n                    size = size + 2;\n                  }\n      size;"
        ]
      },
      "textGravity": {
        "#js-expr": [
          "var align = 'LEFT';\nif(rc('masterConfig.components.appBar.alignment') == 'Centered'){\n  align = 'CENTER'\n}\nalign;"
        ]
      },
      "padding": {
        "#js-expr": [
          "var arr = rc('masterConfig.components.appBar.padding');\nif(rc('masterConfig.components.appBar.alignment') == 'Centered'){\n  arr[2] = arr[2]+30;\n}\narr;"
        ]
      },
      "height": 58,
      "visibility": {
        "#js-expr": [
          "var visible; if(rc('masterConfig.components.appBar.toolbarVisibility')){\n visible = 'visible' \n} else {\n visible = 'gone' \n}\n visible;"
        ]
      },
      "imageUrl": {
        "#js-expr": [
          "(window.getIcons && JSON.parse(window.getIcons()).toolbarBackArrow) ? JSON.parse(window.getIcons()).toolbarBackArrow : 'toolbar_back_arrow'"
        ]
      },
      "contentMargin": {
        "#js-expr": [
          "var uiPadding = rc('screenConfig.uiCard.horizontalPadding');\n                  var topMargin = rc('flowConfig.drawFromStatusBar') ? window.getStatusBarHeight() : 0;\n                  [5, topMargin, 0, 0]"
        ]
      },
      "font": {
        "#ref": [
          "globalConfig.fontBold"
        ]
      },
      "translation": {
        "#if": [
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.visible"
            ]
          },
          {
            "#ref": [
              "masterConfig.themes.Shadow.cardShadow.nativeShadow"
            ]
          },
          0
        ]
      },
      "leftIcon": {
        "size": {
          "#ref": [
            "masterConfig.components.appBar.leftIconSize"
          ]
        },
        "url": {
          "#js-expr": [
            "(window.getIcons && JSON.parse(window.getIcons()).toolbarBackArrow) ? JSON.parse(window.getIcons()).toolbarBackArrow : 'toolbar_back_arrow'"
          ]
        }
      },
      "useGradient": {
        "#ref": [
          "masterConfig.components.appBar.useGradient.visible"
        ]
      },
      "gradient": {
        "angle": {
          "#ref": [
            "masterConfig.components.appBar.useGradient.angle"
          ]
        },
        "values": [
          {
            "#ref": [
              "masterConfig.components.appBar.useGradient.colorValues.endColor"
            ]
          },
          {
            "#ref": [
              "masterConfig.components.appBar.useGradient.colorValues.startColor"
            ]
          }
        ],
        "type": {
          "#ref": [
            "masterConfig.components.appBar.useGradient.type"
          ]
        }
      }
    },
    "offersPreviewListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.leftImage.visibility": "gone",
          "topView.leftImage.size": 0,
          "topView.firstLine.imageOne.size": {
            "#ref": [
              "masterConfig.components.listItems.primaryIconSize"
            ]
          },
          "topView.firstLine.imageOne.position": "left",
          "topView.firstLine.imageOne.visibility": "VISIBLE",
          "topView.firstLine.imageOne.placeholder": "",
          "topView.firstLine.textOne.visibility": "VISIBLE",
          "topView.firstLine.textOne.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "topView.firstLine.textOne.size": {
            "#ref": [
              "globalConfig.fontSize"
            ]
          },
          "topView.firstLine.textOne.color": {
            "#ref": [
              "globalConfig.textPrimaryColor"
            ]
          },
          "topView.firstLine.visibility": "VISIBLE",
          "topView.secondLine.text.padding": [
            0,
            8,
            0,
            0
          ],
          "topView.secondLine.text.margin": [
            0,
            0,
            0,
            0
          ],
          "topView.secondLine.text.size": {
            "#ref": [
              "masterConfig.components.listItems.subText.fontSize"
            ]
          },
          "topView.secondLine.text.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "topView.secondLine.text.color": "#0A8F67",
          "topView.secondLine.text.visibility": "VISIBLE",
          "topView.secondLine.visibility": "VISIBLE",
          "topView.selectionLabel.size": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "topView.selectionLabel.color": "#ffffff",
          "topView.selectionLabel.background": {
            "#ref": [
              "globalConfig.primaryColor"
            ]
          },
          "topView.selectionLabel.padding": [
            16,
            8,
            16,
            8
          ],
          "topView.selectionLabel.cornerRadius": 3,
          "topView.selectionLabel.height": "wrap_content",
          "topView.firstLine.textOne.padding": [
            0,
            0,
            30,
            0
          ],
          "topView.firstLine.textOne.margin": [
            0,
            0,
            20,
            0
          ],
          "topView.firstLine.imageOne.padding": [
            0,
            0,
            0,
            0
          ],
          "topView.secondLine.text.useHTMLForText": true
        }
      ]
    },
    "addButtonListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.rightImage.visibility": "GONE",
          "topView.leftImage.visibility": "VISIBLE",
          "topView.firstLine.textOne.visibility": "VISIBLE",
          "topView.firstLine.visibility": "VISIBLE",
          "divider.visibility": "GONE"
        }
      ]
    },
    "codListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.button.text.text": "Place Order"
        }
      ]
    },
    "ppOfferListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.leftImage.size": 18,
          "topView.selectionType": {
            "#if": [
              {
                "#ref": [
                  "masterConfig.components.offers.rightIconType"
                ]
              },
              "Checkbox",
              "Label"
            ]
          },
          "topView.selectionLabel.text": "View All",
          "topView.selectionLabel.font": {
            "#ref": [
              "globalConfig.fontBold"
            ]
          },
          "topView.selectionLabel.color": {
            "#ref": [
              "globalConfig.primaryColor"
            ]
          },
          "topView.height": 40,
          "topView.firstLine.textOne.size": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "topView.rightImage.url": {
            "#js-expr": [
              "var x = \"\"; try { x = (JSON.parse(window.getIcons())).rightArrow || \"\" ;} catch(err) { x = \"\"; } x;"
            ]
          },
          "divider.visibility": "gone"
        }
      ]
    },
    "unlinkedWalletListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.button.height": "48",
          "bottomView.button.width": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              275,
              "match_parent"
            ]
          },
          "bottomView.editText.visibility": "GONE"
        }
      ]
    },
    "upiAppListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.rightImage.visibility": "visible",
          "topView.rightImage.usePackageIcon": false,
          "topView.isClickable": true,
          "bottomView.bottomDefaultExpand": false,
          "bottomView.editText.visibility": "gone",
          "bottomView.fifthLine.visibility": "gone",
          "divider.visibility": "visible"
        }
      ]
    },
    "nbScreenOtherBanksListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.editText.visibility": "gone",
          "bottomView.button.width": "match_parent"
        }
      ]
    },
    "ppSavedCardListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.secondLine.visibility": "visible",
          "topView.secondLine.text.margin": [
            0,
            {
              "#ref": [
                "masterConfig.components.listItems.spacingBetween"
              ]
            },
            0,
            0
          ],
          "topView.secondLine.text.visibility": "visible",
          "topView.fourthLine.margin": [
            0,
            10,
            0,
            0
          ],
          "topView.fourthLine.image.url": "https://assets.juspay.in/hyper/images/common/jp_secured.png",
          "topView.fourthLine.image.visibility": "visible",
          "topView.fourthLine.visibility": "gone",
          "topView.fourthLine.text.color": "#3BB240",
          "topView.fourthLine.background": {
            "#ref": [
              "screenConfig.uiCard.color"
            ]
          },
          "topView.fourthLine.text.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "topView.thirdLine.text.padding": [
            18,
            5,
            0,
            0
          ],
          "topView.thirdLine.text.color": "#32a852",
          "bottomView.editTextWeight": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              0.25,
              0.33
            ]
          },
          "bottomView.buttonWeight": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              0.85,
              0.75
            ]
          },
          "bottomView.button.margin": {
            "#js-expr": [
              "if (window.isDesktopView()) {\n                [20, 0, 0, 0]\n              } else {\n                var type = rc('masterConfig.components.inputFields.type')\n                if(type == 'materialView'){\n                    [20,4,0,0]\n                } else {\n                      [16,0,0,0]\n                  }\n}"
            ]
          },
          "bottomView.editText.hint.text": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              "C V V",
              "•••"
            ]
          },
          "bottomView.editText.icon.height": 0,
          "bottomView.editText.icon.width": 0,
          "bottomView.button.width": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              250,
              "match_parent"
            ]
          },
          "bottomView.button.height": "48",
          "bottomView.editText.input.height": "48",
          "bottomView.editText.input.gravity": "CENTER_HORIZONTAL",
          "bottomView.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding');\nvar extras = 10;\nif (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, padding]; else if(buttonLayout == 'Stretched') [padding, 0, padding, padding]"
            ]
          },
          "bottomView.editText.input.padding": [
            13,
            4,
            10,
            4
          ],
          "bottomView.editText.focus": true,
          "bottomView.editText.stroke": {
            "#if": [
              {
                "#eq": [
                  {
                    "#ref": [
                      "masterConfig.components.inputFields.type"
                    ]
                  },
                  "underline"
                ]
              },
              "",
              {
                "#js-expr": [
                  "var color = rc(\"masterConfig.components.inputFields.activeStateColor\"); \"1,\"+ color"
                ]
              }
            ]
          },
          "bottomView.editText.input.letterSpacing": 1,
          "bottomView.editText.input.textSize": 14,
          "bottomView.editText.input.inpType": "NumericPassword",
          "bottomView.editText.icon.visibility": "GONE",
          "bottomView.fifthLine.visibility": "gone"
        }
      ]
    },
    "savedVPAListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.firstLine.textTwo.visibility": "gone",
          "topView.secondLine.visibility": "visible",
          "topView.secondLine.text.visibility": "visible",
          "bottomView.editText.visibility": "gone",
          "bottomView.button.width": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              275,
              "match_parent"
            ]
          }
        }
      ]
    },
    "linkedWalletListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.button.height": "48"
        }
      ]
    },
    "quickPayUnlinkedWallet": {
      "#override": [
        "defaultListItem",
        {
          "topView.isClickable": false,
          "topView.selectionType": "label",
          "divider.visibility": "gone",
          "topView.padding": [
            0,
            16,
            0,
            16
          ]
        }
      ]
    },
    "quickPayNB": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.editText.visibility": "gone",
          "bottomView.button.width": "match_parent",
          "divider.visibility": "GONE",
          "topView.padding": [
            0,
            16,
            0,
            16
          ],
          "divider.color": "#ff000000",
          "topView.secondLine.visibility": "VISIBLE",
          "topView.isClickable": false,
          "topView.secondLine.text.visibility": "VISIBLE",
          "topView.selectionType": "label",
          "topView.selectionLabel.text": "Change"
        }
      ]
    },
    "quickPaySavedCard": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.visibility": "visible",
          "bottomView.editText.visibility": "visible",
          "bottomView.margin": [
            0,
            0,
            0,
            0
          ],
          "bottomView.padding": [
            0,
            0,
            0,
            40
          ],
          "topView.padding": [
            0,
            16,
            0,
            16
          ],
          "topView.leftImage.margin": [
            0,
            0,
            9,
            0
          ],
          "topView.isClickable": false,
          "bottomView.editText.hint.hide": false,
          "bottomView.editText.hint.text": "●●●",
          "bottomView.editText.icon.visibility": "gone",
          "bottomView.editText.icon.textVisibility": "gone",
          "bottomView.editText.header.text": "",
          "bottomView.editText.focus": true,
          "bottomView.editText.input.inpType": "NumericPassword",
          "bottomView.editText.input.letterSpacing": 0,
          "bottomView.editText.stroke": "1,#0c161b",
          "bottomView.editText.cornerRadius": 8,
          "bottomView.editText.input.height": 48,
          "bottomView.editText.input.padding": [
            5,
            0,
            5,
            0
          ],
          "bottomView.editText.input.gravity": "center",
          "topView.secondLine.text.visibility": "visible",
          "topView.secondLine.visibility": "visible",
          "topView.selectionType": "label",
          "topView.firstLine.textTwo.visibility": "gone",
          "topView.firstLine.imageTwo.visibility": "visible",
          "topView.selectionLabel.text": "Change",
          "topView.firstLine.imageTwo.margin": [
            8,
            0,
            0,
            0
          ],
          "topView.fourthLine.margin": [
            45,
            10,
            0,
            0
          ],
          "topView.fourthLine.image.url": "https://assets.juspay.in/hyper/images/common/jp_secured.png",
          "topView.fourthLine.image.visibility": "VISIBLE",
          "topView.fourthLine.text.color": "#3BB240",
          "topView.fourthLine.background": {
            "#ref": [
              "screenConfig.uiCard.color"
            ]
          },
          "topView.fourthLine.text.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "divider.visibility": "gone",
          "topView.fourthLine.visibility": "gone",
          "bottomView.showAccordionContentFirst": false,
          "bottomView.button.margin": [
            20,
            10,
            0,
            10
          ]
        }
      ]
    },
    "quickPayLinkedWallet": {
      "#override": [
        "defaultListItem",
        {
          "topView.rightImage.visibility": "gone",
          "topView.firstLine.textTwo.visibility": "gone",
          "topView.isClickable": false,
          "topView.secondLine.text.useHTMLForText": true,
          "topView.secondLine.text.visibility": "visible",
          "topView.secondLine.visibility": "visible",
          "bottomView.visibility": "gone",
          "divider.visibility": "gone",
          "topView.selectionType": "label",
          "topView.padding": [
            0,
            16,
            0,
            16
          ]
        }
      ]
    },
    "retrySuggestionListItem": {
      "#override": [
        "defaultListItem",
        {
          "background": "#fafbfb",
          "topView.firstLine.visibility": "visible",
          "topView.firstLine.textOne.visibility": "visible",
          "topView.firstLine.textTwo.visibility": "gone",
          "topView.firstLine.imageOne.visibility": "gone",
          "topView.thirdLine.text.text": "Experience One Click payment with Pay Later",
          "topView.thirdLine.text.margin": [
            0,
            10,
            0,
            10
          ],
          "topView.rightSectionVisibility": "GONE",
          "topView.isClickable": false,
          "topView.secondLine.text.color": "#909191",
          "topView.secondLine.text.visibility": "VISIBLE",
          "bottomView.visibility": "VISIBLE",
          "bottomView.margin": [
            0,
            0,
            0,
            0
          ],
          "bottomView.button.visibility": "VISIBLE",
          "bottomView.button.height": 48,
          "bottomView.button.margin": [
            16,
            0,
            16,
            0
          ],
          "bottomView.button.cornerRadius": 4,
          "bottomView.button.text.font": {
            "#ref": [
              "globalConfig.fontBold"
            ]
          },
          "bottomView.button.text.padding": [
            70,
            15,
            70,
            15
          ],
          "divider.visibility": "GONE",
          "bottomView.divider": "GONE"
        }
      ]
    },
    "rewardsListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.padding": [
            {
              "#js-expr": [
                "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
              ]
            },
            16,
            {
              "#js-expr": [
                "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
              ]
            },
            0
          ],
          "topView.fourthLine.margin": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size'); var extras = 12;  if (window.isDesktopView()){\n  extras = 12;\n}\nvar space = imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 6, 0, 0];  else if(buttonLayout == 'Stretched') [0, 6, 0, 0]"
            ]
          },
          "topView.fourthLine.text.size": 12,
          "topView.fourthLine.text.color": "#0A8F67",
          "topView.fourthLine.text.font": {
            "#js-expr": [
              "rc('globalConfig.fontRegular')"
            ]
          }
        }
      ]
    },
    "inAppListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.visibility": "gone",
          "topView.leftImage.visibility": "visible",
          "topView.leftImage.placeholder": "cred",
          "bottomView.fifthLine.visibility": "gone",
          "topView.fourthLine.image.visibility": "GONE",
          "topView.fourthLine.background": {
            "#ref": [
              "screenConfig.uiCard.color"
            ]
          },
          "topView.fourthLine.text.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "topView.fourthLine.text.visibility": "visible",
          "topView.fourthLine.padding": {
            "#js-expr": [
              "var imageSize = rc('defaultListItem.topView.leftImage.size');\nextras = 10; if (window.isDesktopView()){\n  extras = 10;\n}\nvar space = imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 6, 0, 0];  else if(buttonLayout == 'Stretched') [0, 6, 0, 0]"
            ]
          },
          "bottomView.editText.visibility": "gone",
          "divider.visibility": "gone"
        }
      ]
    },
    "ppSavedVPAListItem": {
      "#override": [
        "defaultListItem",
        {
          "bottomView.button.height": "48",
          "topView.secondLine.text.visibility": "VISIBLE",
          "topView.secondLine.visibility": "VISIBLE",
          "bottomView.editText.visibility": "GONE"
        }
      ]
    },
    "emiOptionsListItem": {
      "#override": [
        "defaultListItem",
        {
          "divider.visibility": "gone",
          "topView.padding": [
            26,
            16,
            26,
            16
          ]
        }
      ]
    },
    "emiPlansListItem": {
      "#override": [
        "defaultListItem",
        {
          "topView.firstLine.textOne.font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "bottomView.editText.hint.text": "CVV",
          "bottomView.editText.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          },
          "bottomView.button.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                5,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          },
          "bottomView.button.width": "MATCH_PARENT",
          "bottomView.padding": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                16
              ],
              [
                0,
                0,
                0,
                16
              ]
            ]
          },
          "topView.padding": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          },
          "topView.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          },
          "topView.firstLine.textOne.width": "MATCH_PARENT",
          "topView.firstLine.textOne.padding": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                3,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          },
          "bottomView.margin": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          }
        }
      ]
    },
    "defaultListItem": {
      "topView": {
        "firstLine": {
          "textOne": {
            "color": {
              "#ref": [
                "masterConfig.components.listItems.mainText.fontColor"
              ]
            },
            "font": {
              "#ref": [
                "globalConfig.fontSemiBold"
              ]
            },
            "size": {
              "#if": [
                {
                  "#js-expr": [
                    "window.isDesktopView()"
                  ]
                },
                {
                  "#ref": [
                    "masterConfig.themes.TypoGraphy.desktopFontBaseSize"
                  ]
                },
                {
                  "#ref": [
                    "masterConfig.components.listItems.mainText.fontSize"
                  ]
                }
              ]
            },
            "margin": [
              0,
              0,
              10,
              0
            ],
            "padding": {
              "#ref": [
                "masterConfig.components.listItems.paddings"
              ]
            }
          },
          "imageOne": {
            "padding": {
              "#ref": [
                "masterConfig.components.listItems.paddings"
              ]
            }
          }
        },
        "secondLine": {
          "text": {
            "color": {
              "#ref": [
                "masterConfig.components.listItems.subText.fontColor"
              ]
            },
            "size": {
              "#ref": [
                "masterConfig.components.listItems.subText.fontSize"
              ]
            },
            "margin": [
              0,
              {
                "#ref": [
                  "masterConfig.components.listItems.spacingBetween"
                ]
              },
              0,
              0
            ],
            "padding": {
              "#ref": [
                "masterConfig.components.listItems.paddings"
              ]
            }
          }
        },
        "leftImage": {
          "size": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              40,
              {
                "#ref": [
                  "masterConfig.components.listItems.primaryIconSize"
                ]
              }
            ]
          },
          "margin": [
            0,
            0,
            0,
            0
          ],
          "padding": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              [
                0,
                0,
                0,
                0
              ],
              [
                0,
                0,
                0,
                0
              ]
            ]
          }
        },
        "rightImage": {
          "size": {
            "#ref": [
              "masterConfig.components.listItems.secondaryIconSize"
            ]
          }
        },
        "selectionLabel": {
          "size": {
            "#ref": [
              "masterConfig.components.links.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.links.fontColor"
            ]
          },
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "background": {
            "#if": [
              {
                "#js-expr": [
                  "window.isDesktopView()"
                ]
              },
              "#ffffff",
              {
                "#ref": [
                  "masterConfig.themes.Colors.defaultTileColor"
                ]
              }
            ]
          },
          "cornerRadius": 2,
          "stroke": ""
        },
        "height": {
          "#ref": [
            "masterConfig.components.listItems.height"
          ]
        },
        "padding": [
          {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
            ]
          },
          16,
          {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.cardPadding');\n                  window.isDesktopView() ? 26 : padding"
            ]
          },
          16
        ]
      },
      "bottomView": {
        "editText": {
          "#override": [
            "defaultEditText",
            {
              "input.height": 48,
              "focus": true,
              "visibility": "GONE"
            }
          ]
        },
        "button": {
          "#override": [
            "defaultPrimaryButton",
            {
              "margin": [
                0,
                0,
                0,
                16
              ],
              "height": 48,
              "width": "match_parent"
            }
          ]
        },
        "margin": {
          "#js-expr": [
            "var imageSize = rc('defaultListItem.topView.leftImage.size');\nvar padding = rc('masterConfig.components.container.cardPadding'); var extras = 10; if (window.isDesktopView()){\n  extras = 10;\n  padding = 26;\n}\nvar space = padding + imageSize + extras;\nvar buttonLayout = rc('masterConfig.components.buttons.layout'); if(buttonLayout == 'Indented') [space, 0, padding, 0];  else if(buttonLayout == 'Stretched') [padding, 0, padding, 0]"
          ]
        },
        "padding": [
          0,
          0,
          0,
          0
        ]
      },
      "divider": {
        "visibility": "visible",
        "color": {
          "#ref": [
            "masterConfig.components.listItems.dividerColor"
          ]
        }
      }
    },
    "pollingScreenConfig": {
      "#override": [
        "screenConfig",
        {
          "bgPrimaryColor": "#ffffff",
          "bgColorForAccountInfo": "#F9F9F9",
          "uiCard.cornerRadius": 10,
          "uiCard.color": "#000000",
          "uiCard.stroke": "2,#F0EFF4",
          "sectionHeader.color": "#555555",
          "bgSecondaryColor": "#F3A745",
          "screenDivider.visibility": "visible",
          "screenDivider.color": "#F0EFF4"
        }
      ]
    },
    "expiryTimerMessage": {
      "#override": [
        "defaultMessage",
        {
          "visibility": "visible",
          "width": "MATCH_PARENT",
          "background": {
            "#ref": [
              "globalConfig.primaryColor"
            ]
          },
          "text.color": {
            "#js-expr": [
              "\n          window.getContrastYIQ(rc('globalConfig.primaryColor'));\n        "
            ]
          },
          "text.size": {
            "#ref": [
              "globalConfig.fontSizeSmall"
            ]
          },
          "text.gravity": "CENTER",
          "padding": [
            8,
            8,
            8,
            8
          ],
          "maxWidth": 70000,
          "text.margin": [
            0,
            0,
            0,
            0
          ]
        }
      ]
    },
    "defaultOutageMessage": {
      "#override": [
        "defaultMessage",
        {
          "text.text": "Experiencing low success rates for this option",
          "text.color": {
            "#ref": [
              "globalConfig.errorColor"
            ]
          },
          "text.margin": [
            60,
            0,
            30,
            10
          ],
          "text.size": 14,
          "text.useHTMLForText": false,
          "maxWidth": 700
        }
      ]
    },
    "addCardSurchargeMessage": {
      "#override": [
        "surchargeMessage",
        {
          "padding": [
            2,
            0,
            4,
            0
          ],
          "text.color": "#A3820E",
          "background": "#ffffff",
          "visibility": "VISIBLE"
        }
      ]
    },
    "cardNumberConfig": {
      "#override": [
        "defaultEditText",
        {
          "input.separator": {
            "#js-expr": [
              "' '"
            ]
          },
          "input.separatorRepeat": "4",
          "hint.text": "Enter Card Number",
          "input.inpType": "numeric",
          "input.pattern": "^([0-9]| )+$,24",
          "icon.width": 40,
          "icon.height": 40
        }
      ]
    },
    "cvvConfig": {
      "#override": [
        "defaultEditText",
        {
          "hint.text": "CVV",
          "input.inpType": "NumericPassword",
          "input.pattern": "^[0-9]+$,3",
          "visibility": "VISIBLE",
          "icon.visibility": "visible",
          "icon.width": {
            "#ref": [
              "globalConfig.checkboxSize"
            ]
          },
          "icon.url": "https://assets.juspay.in/hyper/images/internalPP/ic_question_mark.png",
          "icon.height": {
            "#ref": [
              "globalConfig.checkboxSize"
            ]
          }
        }
      ]
    },
    "expiryDateConfig": {
      "#override": [
        "defaultEditText",
        {
          "hint.text": "MM / YY",
          "input.separator": "/",
          "input.separatorRepeat": "2",
          "input.inpType": "Numeric",
          "input.pattern": "^([0-9]|\\/)+$,5",
          "visibility": "VISIBLE",
          "icon.textVisibility": "gone",
          "icon.visibility": "visible",
          "input.width": "wrap_content",
          "error.textFont": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          }
        }
      ]
    },
    "orderDescription": {
      "#js-expr": [
        "var text = \"\";\n          try {\n            var payload = (window.__payload.payload);\n            var description = payload.description;\n            text =  description ? description : \"This is your order name\";\n          } catch (e) {\n            text = \"This is your order name\";\n          }\n          text;"
      ]
    },
    "lineItems1": [
      {
        "leftText": {
          "text": {
            "#ref": [
              "orderDescription"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            13,
            0,
            10
          ],
          "gravity": "center",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "<amount>",
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            0,
            12,
            16,
            10
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "lineItems2": [
      {
        "leftText": {
          "text": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.text"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.labelText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.labelText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            7,
            0,
            0
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": {
            "#ref": [
              "orderDescription"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            6,
            0,
            8
          ],
          "gravity": "center",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "<amount>",
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            0,
            3,
            16,
            8
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "lineItems3": [
      {
        "leftImage": {
          "url": {
            "#ref": [
              "masterConfig.components.OrderSummary.leftImage.url"
            ]
          },
          "visibility": "VISIBLE",
          "height": {
            "#ref": [
              "masterConfig.components.OrderSummary.leftImage.size"
            ]
          },
          "width": {
            "#js-expr": [
              "var height = rc('masterConfig.components.OrderSummary.leftImage.size'); var width = height + 40; width;"
            ]
          },
          "usePackageIcon": false,
          "margin": {
            "#ref": [
              "masterConfig.components.OrderSummary.leftImage.margin"
            ]
          },
          "padding": [
            0,
            0,
            0,
            0
          ],
          "cornerRadius": 5
        },
        "rightText": {
          "text": "",
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            0,
            10,
            16,
            0
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "lineItems4": [
      {
        "leftText": {
          "text": {
            "#ref": [
              "orderDescription"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            6,
            0,
            4
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": "<amount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            0,
            0,
            7
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "lineItems5": [
      {
        "leftText": {
          "text": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.text"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.labelText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.labelText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            7,
            0,
            0
          ],
          "gravity": "center",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "Amount",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            0,
            7,
            16,
            2
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": {
            "#ref": [
              "orderDescription"
            ]
          },
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.orderNameText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            16,
            6,
            0,
            8
          ],
          "gravity": "center",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "<amount>",
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.components.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": [
            0,
            3,
            16,
            8
          ],
          "gravity": "center",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "desktopLineItems1": [
      {
        "leftText": {
          "text": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.text"
            ]
          },
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            82,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "Amount",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            151,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": {
            "#ref": [
              "orderDescription"
            ]
          },
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            81,
            0,
            0,
            0
          ],
          "gravity": "left"
        },
        "rightText": {
          "text": "<amount>",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            172,
            0,
            0,
            0
          ],
          "gravity": "left"
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "desktopLineItems2": [
      {
        "rightText": {
          "text": "<amount>",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            172,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "desktopLineItems3": [
      {
        "leftText": {
          "text": "",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            82,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "Amount",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            151,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": "",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.orderNameText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.orderNameText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            81,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "<amount>",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            172,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "desktopLineItems4": [
      {
        "leftText": {
          "text": "Amount",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            82,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "",
          "font": {
            "#js-expr": [
              "var fonts = rc('globalConfig.fontRegular');\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'Bold')\n{\n  fonts = rc('globalConfig.fontBold')\n}\nif(rc('masterConfig.components.OrderSummary.amountText.fontWeight') == 'SemiBold'){\n  fonts = rc('globalConfig.fontSemiBold')\n}\nfonts;"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.labelText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            151,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "leftText": {
          "text": "<amount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            81,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        },
        "rightText": {
          "text": "",
          "font": {
            "#ref": [
              "globalConfig.fontRegular"
            ]
          },
          "size": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontSize"
            ]
          },
          "color": {
            "#ref": [
              "masterConfig.desktopView.OrderSummary.amountText.fontColor"
            ]
          },
          "stroke": "",
          "minWidth": 200,
          "padding": [
            172,
            0,
            0,
            0
          ],
          "gravity": "left",
          "useTextFromHtml": false
        }
      },
      {
        "rightText": {
          "text": "<surchargeAmount>",
          "font": {
            "#ref": [
              "globalConfig.fontSemiBold"
            ]
          },
          "size": {
            "#ref": [
              "globalConfig.fontSizeVerySmall"
            ]
          },
          "color": {
            "#ref": [
              "globalConfig.textSecondaryColor"
            ]
          },
          "stroke": "",
          "minWidth": "MATCH_PARENT",
          "padding": {
            "#js-expr": [
              "var padding = rc('masterConfig.components.container.containerPadding');\n              var rightVal = padding[2];\n                  [0, 0, rightVal + 4, 4]"
            ]
          },
          "gravity": "center",
          "useTextFromHtml": false
        },
        "visibility": {
          "#js-expr": [
            "var vis = \"GONE\";\nif(rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'Split' || rc('masterConfig.controls.features.surcharge.surchargeOnAmountBar') == 'TotalWithSurcharge')\n{\n  vis = \"visible\"\n}\nvis;"
          ]
        }
      }
    ],
    "dotp_config": {
      "uiconfig": {
        "submitButtonColor": "#0099ff",
        "isTextInAllCaps": false,
        "isFullScreenActivity": true,
        "resendColor": "#000000",
        "toolbarBackground": "#ffffff",
        "background": "#ffffff",
        "toolbarTextColor": "#2F3043",
        "toolbarBackImage": "toolbar_back_arrow",
        "primaryFont": "Roboto",
        "toolbarTextSize": 20,
        "toolbarTextFontFace": "Regular",
        "cornerRadius": 5,
        "otpEditTextBackground": "#FFFFFF",
        "headerText": "Payment",
        "merchantName": "",
        "toolbarPrimaryTextMargin": 12,
        "toolbarLetterSpacing": 0,
        "toolbarButtonLayoutHeight": 64,
        "toolbarButtonLayoutWidth": -2,
        "toolbarButtonMargin": 16,
        "cancelDialogNoButton": "#2F3043",
        "cancelDialogYesButton": "#BEBEBE",
        "dialogPrimaryTextColor": "#99000000",
        "dialogHeaderTextColor": "#DE000000",
        "dialogBoxCornerRadius": 8,
        "invertDialogCTA": true,
        "dialogPrimaryTextFontFace": "Regular",
        "popUpImage": "https://assets.juspay.in/juspay/assets/images/error.png",
        "editTextFocusColor": "#2F3043",
        "fontWeight": "-SemiBold",
        "toolbarHeight": 64,
        "setStroke": true
      },
      "flowconfig": {
        "allowSmsReader": false,
        "allowSmsConsentReader": false,
        "allowClipboardReader": false,
        "showSmsReaderCounter": 3,
        "showSmsConsentReaderCounter": 3,
        "showClipboardReaderCounter": 3,
        "allowAutoSubmit": false,
        "delayAutoSubmitInSeconds": 3,
        "globalAutoReadTimerInSeconds": 30,
        "delayResendInSeconds": 3
      },
      "fullPageGodel": {
        "excludeUrlList": [
          "https://securegw\\.paytm\\.in/instaproxy/directbank/.*"
        ],
        "excludeTime": 8000,
        "includeUrlList": [
          "https://netsafe\\.hdfcbank\\.com/ACSWeb/authJsp/authImprovedHopsTxnPage\\.jsp.*"
        ],
        "includeTime": 5000,
        "ignoreUrlList": [
          "https://sandbox\\.juspay\\.in/v2/pay/start/.*",
          "https://securegw\\.paytm\\.in/theia/v1/directBankCardPayment.*",
          "https://securegw\\.paytm\\.in/instaproxy/direct/payment/payonbank/v2.*"
        ],
        "ignoreUrlTime": 3000,
        "defaultTime": 7000,
        "specificUrlList": {
          "https://securegw\\.paytm\\.in/theia/v1/transactionStatus.*": 10000
        }
      }
    },
    "upiintent_config": {
      "global_config": {
        "txnRefLogic": "TXN_ID",
        "priorityApps": [
          "com.google.android.apps.nbu.paisa.user",
          "com.phonepe.app",
          "net.one97.paytm"
        ],
        "filter_list": {
          "filter_type": "blacklist",
          "list": [ "com.application.zomato",
          ]
        },
        "filter_list_mandate": {
                  "filter_type": "blacklist",
                  "list": [
                    "com.olacabs.customer",
                    "com.nextbillion.groww"
                  ]
                }
      }
    }
  }
};
      return JSON.stringify(configuration);
      }