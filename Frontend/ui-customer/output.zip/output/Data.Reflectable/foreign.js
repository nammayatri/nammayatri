// module Data.Reflectable

export const unsafeCoerce = function (arg) {
  return arg;
};
