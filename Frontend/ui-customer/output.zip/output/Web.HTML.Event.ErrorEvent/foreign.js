export function message(e) {
  return e.message;
}

export function fileName(e) {
  return e.filename;
}

export function lineNo(e) {
  return e.lineno;
}

export function colNo(e) {
  return e.colno;
}
