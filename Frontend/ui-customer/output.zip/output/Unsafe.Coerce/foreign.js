// module Unsafe.Coerce

export const unsafeCoerce = function (x) {
  return x;
};
