export function data_(e) {
  return e.data;
}
