export const unsafeStringify = x => {
  return JSON.stringify(x);
};