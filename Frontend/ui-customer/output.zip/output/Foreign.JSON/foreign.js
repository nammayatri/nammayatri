"use strict";

export const parseJSONImpl = function (str) {
  return JSON.parse(str);
};
