export function _key(storage) {
  return storage.key;
}

export function _oldValue(storage) {
  return storage.oldValue;
}

export function _newValue(storage) {
  return storage.newValue;
}

export function url(storage) {
  return storage.url;
}

export function _storageArea(storage) {
  return storage.storageArea;
}
