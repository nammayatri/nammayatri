
export const eqPropValues = function (x) {
  return function (y){
    return x == y;
  };
};
